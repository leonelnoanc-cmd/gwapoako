# Supabase Final Setup Guide - Step by Step

Your Supabase integration is ready! Follow these 4 steps to complete the setup:

---

## Step 1: Run Database Schema in Supabase ✅

### Instructions:
1. **Open Supabase Dashboard**
   - Go to https://app.supabase.com/projects
   - Select your project: `wgnbejkryaswxvvhmaff`

2. **Navigate to SQL Editor**
   - Click **"SQL Editor"** in the left sidebar
   - Click **"New Query"** button

3. **Copy & Paste the Schema**
   - Open the file: `supabase-schema.sql` in this project
   - Copy **ALL** the SQL code (lines 1-195)
   - Paste it into the Supabase SQL Editor
   - **DO NOT** execute the commented sample data at the bottom (lines 190-195)

4. **Execute the Schema**
   - Click the **"Run"** button (or press Ctrl+Enter)
   - You should see: ✅ "Query executed successfully"
   - Check the sidebar: You should now see 6 new tables:
     - `submissions`
     - `revisions`
     - `timelines`
     - `groups`
     - `group_members`
     - `notifications`

### What This Does:
- Creates 6 PostgreSQL tables for your research paper system
- Adds indexes for fast queries
- Sets up Row Level Security policies (optional, commented out)
- Prepares your database to store submissions, revisions, timelines, and notifications

---

## Step 2: Create Storage Bucket 🪣

### Instructions:
1. **Navigate to Storage**
   - In Supabase Dashboard, click **"Storage"** in the left sidebar

2. **Create New Bucket**
   - Click **"Create a new bucket"** button
   - Bucket name: `research-papers`
   - Leave all settings as default
   - Click **"Create bucket"** button

3. **Make Bucket Public** (Important!)
   - Click on the bucket name: `research-papers`
   - Click **"Settings"** tab
   - Under **"Access Control"**, select **"Public"**
   - Save changes

### What This Does:
- Creates a public storage location for PDF files
- Allows anyone with a link to download submitted papers
- Your server will upload files here with public URLs

---

## Step 3: Test the Upload Feature 🚀

### Important Prerequisites:
- ✅ The server MUST be running: `node server/server.js` (port 3000)
- ✅ The database schema must be created (Step 1)
- ✅ The storage bucket must exist and be public (Step 2)

### Instructions:
1. **Open Your Browser**
   - Go to: `http://localhost:3000/research-paper-editor.html`

2. **Create a Test Submission**
   - Fill in the form:
     - Student ID: `test-student-123`
     - Student Name: `Test Student`
     - Paper Title: `Test Paper Upload`
     - Chapter: `1`
     - Part: `Introduction`
   - Click **"Choose File"** and select any PDF (or create a simple one)
   - Click **"Submit"**

3. **Expected Results** ✅
   - You should see a success message: `"Submission created with ID: xxx"`
   - In Supabase Dashboard → **Table Editor** → `submissions`
   - You should see a new row with your test data

4. **Verify File Upload**
   - Go to Supabase → **Storage** → `research-papers`
   - You should see a PDF file uploaded: `1/1/test.pdf` (or similar path)

### Troubleshooting:
If upload fails:
- Check browser console (F12 → Console tab) for errors
- Verify the server is running: `netstat -ano | findstr 3000`
- Confirm `.env` file exists with correct credentials
- Check Supabase logs: Dashboard → Logs

---

## Step 4: Rotate Your Service Key 🔑 (Security)

⚠️ **IMPORTANT: Your JWT service key was exposed in the chat!**

### Instructions:
1. **Go to Supabase Settings**
   - Supabase Dashboard → Click **Settings** (⚙️) → **API**

2. **Find Service Role Secret**
   - Locate **"Service Role Secret"** (starts with `eyJhbGci...`)
   - Click **"Regenerate"** button

3. **Copy New Key**
   - Copy the new key immediately
   - Update `.env` file in your project:
     ```
     SUPABASE_SERVICE_ROLE_KEY=<new_key_here>
     ```

4. **Restart Server**
   - Kill the running server: `taskkill /IM node.exe /F`
   - Restart: `node server/server.js`
   - The .env file will be reloaded automatically

### What This Does:
- Invalidates the old exposed key
- Prevents unauthorized access to your Supabase project
- Your server continues to work with the new key

---

## Summary - What's Ready ✅

| Component | Status | Location |
|-----------|--------|----------|
| Express Server | ✅ Running | `server/server.js` |
| Supabase Client | ✅ Configured | `server/supabase-client.js` |
| Upload Endpoints | ✅ Mounted | `/api/submissions/upload` |
| Database Schema | ⏳ Manual: Step 1 | `supabase-schema.sql` |
| Storage Bucket | ⏳ Manual: Step 2 | `research-papers` |
| Upload Testing | ⏳ Manual: Step 3 | `http://localhost:3000/...` |
| Service Key Security | ⏳ Manual: Step 4 | Supabase Settings |

---

## API Endpoints Available

Once everything is set up, these endpoints are live:

```javascript
POST   /api/submissions/upload          // Upload a paper
GET    /api/submissions/:studentId      // Get student's submissions
GET    /api/submissions/:id/status      // Check submission status
PATCH  /api/submissions/:id/status      // Update submission status
POST   /api/revisions/:id/request       // Request revision
GET    /api/revisions/:submissionId     // Get revisions history
POST   /api/timeline                    // Create timeline event
GET    /api/timeline                    // Get timeline events
POST   /api/notifications               // Create notification
GET    /api/notifications/:recipientId  // Get notifications
```

---

## Environment Configuration ✅

Your `.env` file is already configured:

```env
SUPABASE_URL=https://wgnbejkryaswxvvhmaff.supabase.co
SUPABASE_ANON_KEY=sb_publishable_zXDoUv_8UPOOm_rSzxNyjg_d_GPDquW
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (ROTATE THIS!)
PORT=3000
```

---

## Questions?

- **Database errors?** Check Supabase Logs: Dashboard → Logs
- **Upload errors?** Check browser console: F12 → Console
- **Connection errors?** Verify `.env` credentials match Supabase project
- **File not uploading?** Ensure bucket is public and multer size limit (50MB) is adequate

---

## Next Steps After Setup

1. **Integrate into Your HTML Pages**
   - Add file upload forms to your existing HTML pages
   - Use the `supabase-upload.js` module for frontend integration

2. **Connect to Your Dashboard**
   - Display submitted papers in student/adviser dashboards
   - Show submission status and revisions

3. **Test with Real Data**
   - Have students submit actual research papers
   - Test revision workflow and notifications

4. **Monitor Performance**
   - Check Supabase Analytics for query performance
   - Monitor storage usage

---

**Setup Completion Date:** January 30, 2026
**Status:** Ready for manual Supabase configuration
