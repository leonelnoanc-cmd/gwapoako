# Timeline & Notification System - Quick Start

## Problem Solved ✅

**Ang issue:**
- Kapag nag-add ng timeline sa adviser dashboard, hindi nag-sync sa student at student leader
- Walang notification sa students at student leaders tungkol sa bagong timeline

**Solusyon:**
- Server-side timeline storage
- Real-time polling every 3 seconds
- Automatic notifications para sa students at leaders
- Multi-device synchronization

---

## How to Use

### 1. Start the Server
```bash
cd server
node server.js
```
Output:
```
✅ Server running on http://localhost:3000
```

### 2. Adviser: Add Timeline Event
```
1. Login as adviser
2. Click Timeline card (🕒) sa sidebar
3. Enter event title: "Project Deadline"
4. Enter date: 2026-02-15
5. Click "Add Event"
6. See success message: "Timeline event added and sent to students!"
```

### 3. Student: See Timeline
```
1. Login as student
2. Open Student Dashboard
3. Wait 3 seconds (first poll)
4. Click Timeline card (🕒)
5. See timeline event from adviser
6. Timeline badge shows event count
```

### 4. Student: Get Notification
```
1. Check Notifications card (bell icon)
2. Unread count badge shows number of new notifications
3. Click Notifications
4. See "New Timeline Event: Project Deadline on 2026-02-15"
```

### 5. Student Leader: Same as Student
- Same process but with role = "student-leader"
- Gets same timeline events
- Gets separate notifications for student leaders

---

## How It Works Behind the Scenes

```
ADVISER SIDE:
  Add Timeline Event
       ↓
  POST /api/timeline
       ↓
  Server stores event
  Server creates notification

STUDENT/LEADER SIDE:
  Poll every 3 seconds
       ↓
  GET /api/timeline
  GET /api/notifications
       ↓
  Display on dashboard
  Show badge count
```

---

## What Changed

### Server (`server/server.js`)
- ✅ Added timeline storage in memory
- ✅ Added notification storage in memory
- ✅ 5 new API endpoints for timeline and notifications

### Adviser Dashboard (`Adviser_dashboard.html`)
- ✅ Enhanced timeline save to use API
- ✅ Auto-creates notifications when adding event

### Student Dashboard (`Student_dashboard.html`)
- ✅ Polls timeline every 3 seconds
- ✅ Polls notifications every 3 seconds
- ✅ Shows timeline badge count
- ✅ Shows notification badge count

### Student Leader Dashboard (`Student-leader.html`)
- ✅ Polls timeline every 3 seconds
- ✅ Polls notifications every 3 seconds
- ✅ Shows timeline badge count
- ✅ Shows notification badge count

---

## Testing Steps

### Test 1: Timeline Sync
```
1. Open Adviser Dashboard in browser (localhost:3000)
2. Open Student Dashboard in ANOTHER BROWSER TAB
3. In Adviser: Add timeline event "Test Event" on 2026-02-25
4. See "Timeline event added and sent to students!"
5. Switch to Student tab
6. Wait 3 seconds (for polling)
7. Click Timeline card
8. See "Test Event - 2026-02-25" ✅
```

### Test 2: Notifications
```
1. Open Student Dashboard
2. Check notification card - may badge na may number
3. Click notification card (bell icon)
4. See details of timeline event ✅
```

### Test 3: Multiple Devices
```
1. Adviser on Device A: Add timeline
2. Student on Device B: Check Student Dashboard
3. Student sees timeline within 3 seconds ✅
4. Student sees notification ✅
```

---

## Key Features

| Feature | Status | Details |
|---------|--------|---------|
| Timeline Sync | ✅ | Appears on all dashboards within 3s |
| Notifications | ✅ | Auto-created when adviser adds event |
| Badge Count | ✅ | Shows unread count on notification card |
| Multi-Device | ✅ | Works across different devices |
| Fallback | ✅ | Uses localStorage if server unavailable |

---

## Common Issues & Fixes

### Timeline not showing on student dashboard
- **Check:** Is server running? (`node server/server.js`)
- **Wait:** Up to 3 seconds for polling
- **Check Console:** Any JavaScript errors?

### No notification badge
- **Wait:** 3 seconds for first poll after page load
- **Refresh:** Try F5 to reload page
- **Check:** Network tab for `/api/notifications` calls

### Adviser success message not showing
- **Check:** Are timeline title and date filled in?
- **Look:** Bottom right of screen for green notification

---

## Next Steps

To add more features later:
- Email notifications
- WebSocket for real-time updates (no polling delay)
- Store notifications in database (not just memory)
- Allow students to acknowledge notifications

---

## API Endpoints (For Developers)

```
GET  /api/timeline                    → Get all timeline events
POST /api/timeline                    → Add timeline event (adviser)
DELETE /api/timeline/:event_id        → Delete event
GET  /api/notifications?role=X        → Get notifications for role X
POST /api/notifications/:id/read      → Mark notification as read
```

---

## Support

If timeline events:
- Don't sync → Check server is running, wait 3 seconds
- Create multiple times → Refresh browser
- Show on adviser only → Log out and log in as student

If notifications don't show:
- Wait 3 seconds after adding timeline
- Check browser console for errors
- Try clearing localStorage: `localStorage.clear()`

---

**System Status: ✅ READY TO USE**

Mag-test ng system ngayon at i-verify na gumagana lahat!
