# Supabase Setup Checklist

## What You Need To Do (Manual Tasks in Supabase Dashboard)

### ☐ Step 1: Create Database Tables (5 minutes)
**What:** Execute SQL schema to create database tables
**Where:** Supabase Dashboard → SQL Editor
**File to Copy:** `SUPABASE_SCHEMA_READY_TO_COPY.sql`

**Detailed Steps:**
1. Log in to https://app.supabase.com
2. Select project `wgnbejkryaswxvvhmaff`
3. Click "SQL Editor" in left sidebar
4. Click "New Query"
5. Open `SUPABASE_SCHEMA_READY_TO_COPY.sql` from this project
6. Copy ALL the SQL code
7. Paste into the Supabase SQL Editor
8. Click "Run" button
9. ✅ Verify: You see 6 new tables in "Table Editor"

**Tables Created:**
- submissions
- revisions
- timelines
- groups
- group_members
- notifications

---

### ☐ Step 2: Create Storage Bucket (2 minutes)
**What:** Create a public storage bucket for PDF uploads
**Where:** Supabase Dashboard → Storage

**Detailed Steps:**
1. In Supabase Dashboard, click "Storage" in left sidebar
2. Click "Create a new bucket"
3. **Bucket name:** `research-papers` (EXACT spelling)
4. Click "Create bucket"
5. Click on bucket name: `research-papers`
6. Click "Settings" tab
7. Change Access Control to **"Public"**
8. Click "Save"
9. ✅ Verify: Bucket appears as public in Storage view

---

### ☐ Step 3: Test Upload Feature (5 minutes)
**What:** Verify the full upload workflow works end-to-end
**Where:** Your browser at `http://localhost:3000`

**Detailed Steps:**
1. ✅ Verify server is running:
   ```
   cd "c:\Users\ADMIN\researchProject (LATEST)"
   node server/server.js
   ```
   Should show: `✅ Supabase endpoints mounted at /api`

2. Open browser: `http://localhost:3000/research-paper-editor.html`

3. Fill the form:
   - Student ID: `test-student-123`
   - Student Name: `Test Student`
   - Paper Title: `Test Paper`
   - Chapter: `1`
   - Part: `Introduction`
   - Choose any PDF file

4. Click "Submit"

5. ✅ Success Indicators:
   - Browser shows: "✅ Submission created"
   - Supabase Dashboard → Table Editor → `submissions` → See new row
   - Supabase Dashboard → Storage → `research-papers` → See PDF file

---

### ☐ Step 4: Rotate Exposed Service Key (2 minutes)
**What:** Invalidate and regenerate your exposed JWT token
**Where:** Supabase Dashboard → Settings → API

**Detailed Steps:**
1. In Supabase Dashboard, click ⚙️ "Settings" (bottom-left)
2. Click "API" in left menu
3. Find "Service Role Secret" section
4. Click "Regenerate" button
5. Copy the NEW key (very long string starting with `eyJhbGci...`)
6. Update your `.env` file:
   ```
   SUPABASE_SERVICE_ROLE_KEY=<paste_new_key_here>
   ```
7. Restart the server:
   ```
   taskkill /IM node.exe /F
   node server/server.js
   ```
8. ✅ Server restarts successfully with new key

---

## Quick Reference

| Task | Time | Status |
|------|------|--------|
| Create DB Tables | 5 min | ☐ TODO |
| Create Storage Bucket | 2 min | ☐ TODO |
| Test Upload | 5 min | ☐ TODO |
| Rotate Service Key | 2 min | ☐ TODO |
| **TOTAL** | **~15 min** | ⏳ IN PROGRESS |

---

## Server Must Be Running

Before testing Step 3, ensure the server is running:

```powershell
cd "c:\Users\ADMIN\researchProject (LATEST)"
node server/server.js
```

Expected output:
```
[dotenv@17.2.3] injecting env from ..\.env
✅ Supabase endpoints mounted at /api
✅ Server running on http://localhost:3000
```

---

## File Locations Reference

| Component | File | Status |
|-----------|------|--------|
| Server Code | `server/server.js` | ✅ Ready |
| Supabase Client | `server/supabase-client.js` | ✅ Ready |
| Upload Endpoints | `server/supabase-endpoints.js` | ✅ Ready |
| Environment Config | `.env` | ✅ Ready |
| Schema (Easy Copy) | `SUPABASE_SCHEMA_READY_TO_COPY.sql` | 👈 Use this |
| Original Schema | `supabase-schema.sql` | ✅ Reference |
| Setup Guide | `SUPABASE_FINAL_SETUP_GUIDE.md` | 📖 Read this |
| Frontend Module | `supabase-upload.js` | ✅ Ready to integrate |

---

## Troubleshooting

### "Cannot find module '@supabase/supabase-js'"
**Solution:** Run `npm install` in the `server/` directory
```powershell
cd "c:\Users\ADMIN\researchProject (LATEST)\server"
npm install
```

### Server won't start
**Solution:** Check if port 3000 is in use
```powershell
netstat -ano | findstr 3000
taskkill /PID <PID> /F
node server/server.js
```

### Upload endpoint returns 404
**Solution:** Verify supabase-endpoints.js is mounted in server/server.js
```powershell
node -c server/server.js
```

### "Missing SUPABASE_URL" error
**Solution:** Ensure `.env` file exists in the project root (not in server/)
```powershell
cat .env  # Should show 5 environment variables
```

---

## When Complete ✅

All 4 tasks completed = **Supabase integration fully operational!**

Your research project can now:
- ✅ Accept paper submissions
- ✅ Store PDFs in cloud storage
- ✅ Track revisions
- ✅ Manage timelines
- ✅ Send notifications
- ✅ Scale to production

---

**Last Updated:** January 30, 2026
**Status:** Awaiting manual Supabase configuration
**Estimated Time to Complete:** 15 minutes
