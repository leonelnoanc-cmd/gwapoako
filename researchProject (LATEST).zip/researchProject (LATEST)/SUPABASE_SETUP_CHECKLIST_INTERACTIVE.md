# ✅ SUPABASE SETUP - STEP-BY-STEP CHECKLIST

**Print this page and check off each step as you complete it!**

---

## PHASE 1: PREPARATION (5 minutes)

- [ ] Read: `00_START_HERE_SUPABASE.md` (2 min)
- [ ] Read: `SUPABASE_QUICK_REFERENCE.md` (2 min)
- [ ] Print: This checklist (bookmark it!)
- [ ] Open: `SUPABASE_FIX_GUIDE.md` in another window

**Status:** ✅ Ready to begin setup

---

## PHASE 2: INSTALL DEPENDENCIES (2 minutes)

**In PowerShell:**
```powershell
cd "C:\Users\ADMIN\researchProject (LATEST)\server"
npm install
```

- [ ] Command runs without errors
- [ ] See: "added XX packages in X.Xs"
- [ ] Check: `node_modules` folder created

**Troubleshoot if needed:**
- Error: Run npm install again
- Missing npm: Install Node.js from nodejs.org
- Still failing: Check internet connection

**Status:** ✅ Dependencies installed

---

## PHASE 3: CONFIGURE ENVIRONMENT (3 minutes)

**Create .env file in PROJECT ROOT (not in server/):**

1. [ ] Check if `.env` exists: `Get-Content .env`
2. [ ] If not, create from template: `Copy-Item .env.example .env`
3. [ ] Edit `.env` with your Supabase credentials:
   - [ ] SUPABASE_URL=https://wgnbejkryaswxvvhmaff.supabase.co
   - [ ] SUPABASE_ANON_KEY=(from Supabase Settings → API)
   - [ ] SUPABASE_SERVICE_ROLE_KEY=(from Supabase Settings → API)
   - [ ] PORT=3000

**Verify:**
```powershell
Get-Content .env  # Should show all 4 variables
```

**Status:** ✅ Environment configured

---

## PHASE 4: CREATE DATABASE TABLES (5 minutes)

**Go to Supabase Dashboard:**
1. [ ] Open: https://app.supabase.com
2. [ ] Login with your credentials
3. [ ] Select project: wgnbejkryaswxvvhmaff

**Create tables:**
1. [ ] Click: "SQL Editor" (left sidebar)
2. [ ] Click: "New Query"
3. [ ] Open file: `SUPABASE_SCHEMA_READY_TO_COPY.sql`
4. [ ] Copy: ALL the SQL code (Ctrl+A, Ctrl+C)
5. [ ] Paste: Into Supabase SQL Editor
6. [ ] Click: "Run" button
7. [ ] Wait: For success message
8. [ ] Check: Click "Table Editor" - you should see 6 tables:
   - [ ] submissions
   - [ ] revisions
   - [ ] timelines
   - [ ] groups
   - [ ] group_members
   - [ ] notifications

**If SQL fails:**
- [ ] Check: No errors in output
- [ ] Retry: Click "Run" again
- [ ] Refresh: Browser page
- [ ] Read: SUPABASE_TROUBLESHOOTING.md → "Table does not exist"

**Status:** ✅ Database tables created

---

## PHASE 5: CONFIGURE STORAGE (3 minutes)

**In Supabase Dashboard:**
1. [ ] Click: "Storage" (left sidebar)
2. [ ] Click: "Create a new bucket"
3. [ ] Name: `research-papers` (exact spelling!)
4. [ ] Click: "Create"

**Make bucket PUBLIC:**
1. [ ] Click: bucket name "research-papers"
2. [ ] Click: "Settings" tab
3. [ ] Find: "Access Control"
4. [ ] Change to: "Public"
5. [ ] Click: "Save"

**Verify:**
- [ ] Bucket appears in storage list
- [ ] Blue "public" badge appears
- [ ] No errors in dashboard

**If bucket errors:**
- [ ] Check: Bucket name is `research-papers` (lowercase, no spaces)
- [ ] Check: Access Control is set to PUBLIC
- [ ] Read: SUPABASE_TROUBLESHOOTING.md → "403 Forbidden"

**Status:** ✅ Storage bucket configured

---

## PHASE 6: ROTATE SERVICE KEY (5 minutes)

**⚠️ SECURITY STEP - Do this because credentials may be exposed**

**In Supabase Dashboard:**
1. [ ] Click: ⚙️ "Settings" (bottom-left corner)
2. [ ] Click: "API" (left menu)
3. [ ] Find: "Service Role Secret" section
4. [ ] Click: "Regenerate" button
5. [ ] See: WARNING dialog (read it)
6. [ ] Click: "Generate" to confirm
7. [ ] Copy: The NEW key (very long string starting with `eyJ...`)

**Update .env file:**
1. [ ] Stop server if running: Ctrl+C
2. [ ] Open: `.env` file
3. [ ] Replace: Old SUPABASE_SERVICE_ROLE_KEY with NEW one
4. [ ] Save: File (Ctrl+S)

**Verify:**
- [ ] `.env` has new key value
- [ ] No errors when saving

**Status:** ✅ Service key rotated securely

---

## PHASE 7: START SERVER (1 minute)

**In PowerShell:**
```powershell
cd "C:\Users\ADMIN\researchProject (LATEST)"
node server/server.js
```

**Look for this output:**
```
✅ SERVER STARTED SUCCESSFULLY
✅ Supabase endpoints mounted at /api
✅ Supabase configuration loaded
📍 URL: http://localhost:3000
```

**If server fails:**
- [ ] Check: Output for error messages
- [ ] Verify: .env has all credentials
- [ ] Check: Port 3000 is free: `netstat -ano | findstr 3000`
- [ ] Read: SUPABASE_TROUBLESHOOTING.md

**Status:** ✅ Server running

---

## PHASE 8: TEST UPLOAD FEATURE (5 minutes)

**Test the complete flow:**

1. [ ] Open browser
2. [ ] Navigate: http://localhost:3000/research-paper-editor.html
3. [ ] Fill form:
   - [ ] Student ID: `test-student-123`
   - [ ] Student Name: `Test Student`
   - [ ] Paper Title: `Test Paper Title`
   - [ ] Chapter: `1`
   - [ ] Part: `Introduction`
   - [ ] File: Choose any PDF file
4. [ ] Click: "Submit" button
5. [ ] Check: Browser shows "✅ Submission created"

**Verify in Supabase Dashboard:**
1. [ ] Go to: Table Editor
2. [ ] Click: `submissions` table
3. [ ] Look for: Row with your test data
   - [ ] student_id = test-student-123
   - [ ] paper_title = Test Paper Title
   - [ ] status = pending

**Verify file in storage:**
1. [ ] Go to: Storage
2. [ ] Click: `research-papers` bucket
3. [ ] Look for: Folder with student ID
4. [ ] Should contain: Your PDF file

**If upload fails:**
- [ ] Check: Browser console (F12 → Console tab) for errors
- [ ] Check: Server logs for error messages
- [ ] Verify: Bucket is PUBLIC (Step 5)
- [ ] Verify: Tables exist (Step 4)
- [ ] Read: SUPABASE_TROUBLESHOOTING.md

**Status:** ✅ Upload functionality working

---

## ✅ FINAL VERIFICATION

Check all of these are TRUE:

- [ ] Server started with ✅ messages
- [ ] /health endpoint works
- [ ] Can upload test paper
- [ ] Data appears in submissions table
- [ ] PDF appears in storage bucket
- [ ] No errors in browser console (F12)
- [ ] No errors in server output

---

## 🎉 SETUP COMPLETE!

If all checkmarks above are filled, your Supabase is fully configured and working!

**What you can do now:**
- [ ] Add upload forms to other HTML pages
- [ ] Build submission dashboards
- [ ] Implement review workflows
- [ ] Add revision tracking
- [ ] Create analytics reports

---

## 📝 NOTES & ISSUES

**If something failed, document it here:**

```
Issue: ____________________________________
Error message: ____________________________
Step where it failed: _____________________
What you tried to fix it: __________________
Result: ___________________________________
```

**Then:**
1. Check SUPABASE_TROUBLESHOOTING.md
2. Run: `node server/verify-setup.js`
3. Share error details if asking for help

---

## 🔄 WHAT'S NEXT?

**After Setup Success:**

### Week 1: Integration
- [ ] Add upload to Student Dashboard
- [ ] Add upload to Adviser Dashboard
- [ ] Test with real users

### Week 2: Features
- [ ] Show submission status
- [ ] Add revision request workflow
- [ ] Send notifications

### Week 3: Monitoring
- [ ] Check Supabase logs
- [ ] Monitor storage usage
- [ ] Review performance metrics

---

## 📞 TROUBLESHOOTING QUICK LINKS

| Issue | Lookup |
|-------|--------|
| Server won't start | SUPABASE_TROUBLESHOOTING.md#Error-EADDRINUSE |
| Upload fails | SUPABASE_FIX_GUIDE.md#Troubleshooting |
| Can't see tables | SUPABASE_TROUBLESHOOTING.md#Error-Table-does-not-exist |
| 403 error on upload | SUPABASE_FIX_GUIDE.md#Step-4 |
| Key errors | SUPABASE_TROUBLESHOOTING.md#Error-Service-role-key |

---

## 💡 HELPFUL TIPS

1. **Keep this checklist visible** while setting up
2. **Don't skip steps** - do them in order
3. **Check for typos** in file names and URLs
4. **When in doubt, restart the server** (Ctrl+C, then node server.js)
5. **F12 in browser** = developer console for errors
6. **Watch server logs** as you test features

---

## 🎓 QUICK REFERENCE

| Thing | Location |
|------|----------|
| Server URL | http://localhost:3000 |
| Test Upload | http://localhost:3000/research-paper-editor.html |
| Health Check | http://localhost:3000/health |
| Supabase Dashboard | https://app.supabase.com |
| Your Project | https://app.supabase.com/project/wgnbejkryaswxvvhmaff |
| SQL Editor | Supabase Dashboard → SQL Editor |
| Table Editor | Supabase Dashboard → Table Editor |
| Storage | Supabase Dashboard → Storage |

---

## ✨ YOU DID IT!

**Setup Time:** ~21 minutes  
**Effort Level:** Easy (follow checklist)  
**Result:** Production-ready system  

If you made it here with all checkmarks ✅, congratulations!

Your Supabase integration is complete and working!

---

## 📋 DOCUMENT REFERENCE

**Keep these bookmarked:**
- `00_START_HERE_SUPABASE.md` - Overview
- `SUPABASE_QUICK_REFERENCE.md` - Quick lookup
- `SUPABASE_FIX_GUIDE.md` - Detailed guide
- `SUPABASE_TROUBLESHOOTING.md` - Problem solving
- This Checklist - Keep printing it!

---

**Status:** Ready for Setup  
**Last Updated:** January 30, 2026  
**Difficulty:** ⭐ Easy (follow steps)  
**Time:** ~21 minutes  

**→ START WITH PHASE 1 ABOVE!** ↑

---

## PRINT VERSION

```
SUPABASE SETUP CHECKLIST
=======================

Phase 1: Preparation        ☐
Phase 2: Install Deps       ☐
Phase 3: Configure Env      ☐
Phase 4: Create Tables      ☐
Phase 5: Configure Storage  ☐
Phase 6: Rotate Key         ☐
Phase 7: Start Server       ☐
Phase 8: Test Upload        ☐

Final Verification          ☐

READY FOR PRODUCTION        ✅
```

---

**Questions?** Check SUPABASE_TROUBLESHOOTING.md  
**Stuck?** Run: `node server/verify-setup.js`  
**Need Help?** Reference: SUPABASE_SETUP_MASTER_GUIDE.md  

**Let's go! 🚀**
