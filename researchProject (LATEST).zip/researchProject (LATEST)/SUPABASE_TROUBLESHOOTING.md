# 🔍 Supabase Troubleshooting Checklist

## Quick Diagnostics

Run these checks to identify your issue:

### 1. Is the server running?
```powershell
# Check if port 3000 is listening
netstat -ano | findstr 3000

# If no output, server is NOT running
# Start it: node server.js
```

### 2. Can you reach the server?
```powershell
# Open PowerShell and test
Invoke-WebRequest http://localhost:3000/health -UseBasicParsing | Select-Object StatusCode, Content

# Expected: StatusCode 200, Content: {"status":"OK","message":"Server is running"}
```

### 3. Are API endpoints available?
```powershell
# Test Supabase endpoints
Invoke-WebRequest http://localhost:3000/api/submissions -UseBasicParsing -ErrorAction SilentlyContinue

# Should work or show specific error (not 404)
```

### 4. Check server logs
```powershell
# If server is running, watch the output:
# Look for:
# ✅ Supabase endpoints mounted at /api
# ✅ Supabase configuration loaded
# ✅ SERVER STARTED SUCCESSFULLY

# If you see ❌ errors, note them exactly
```

---

## Common Issues & Fixes

### Issue: "Port 3000 already in use"
```powershell
# Find the process
netstat -ano | findstr 3000
# Result example: TCP  0.0.0.0:3000 LISTENING 1234

# Kill it (use PID from above, e.g., 1234)
taskkill /PID 1234 /F

# Try again
node server.js
```

### Issue: "Cannot find module '@supabase/supabase-js'"
```powershell
cd server
npm install
npm install @supabase/supabase-js
```

### Issue: "Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY"
```powershell
# 1. Check .env exists (in PROJECT ROOT, not in server/)
Test-Path .env

# 2. Check it has content
Get-Content .env

# 3. Copy from .env.example if missing
Copy-Item .env.example .env

# 4. Add your Supabase credentials
# Edit .env with your values
```

### Issue: Upload fails with "Table does not exist"
1. Log in to https://app.supabase.com
2. Select project: wgnbejkryaswxvvhmaff
3. Go to SQL Editor → New Query
4. Copy entire SQL from: SUPABASE_SCHEMA_READY_TO_COPY.sql
5. Paste and click "Run"
6. Go to Table Editor, verify 6 tables appear
7. Try upload again

### Issue: Upload fails with "403 Forbidden"
1. Go to Supabase Dashboard → Storage
2. Click bucket: research-papers
3. Click Settings tab
4. Change "Access Control" to "Public"
5. Click "Save"
6. Try upload again

### Issue: "Service role key is invalid"
1. Go to Supabase Dashboard → Settings → API
2. Click "Regenerate" on Service Role Secret
3. Copy the NEW key
4. Stop server (Ctrl+C)
5. Edit .env: Update SUPABASE_SERVICE_ROLE_KEY with new value
6. Restart: node server.js

### Issue: "Invalid API key" or connection error
1. Go to Supabase: https://app.supabase.com
2. Select project: wgnbejkryaswxvvhmaff
3. Go to Settings → API
4. Verify your keys match .env file:
   - SUPABASE_URL should match "Project URL"
   - SUPABASE_ANON_KEY should match "anon key"
   - SUPABASE_SERVICE_ROLE_KEY should match "service_role secret"
5. Update .env if they differ
6. Restart server

---

## Testing the Full Flow

Once server is running, test the complete submission flow:

1. **Navigate to the app:**
   - Open: http://localhost:3000/research-paper-editor.html

2. **Fill the form:**
   - Student ID: test-123
   - Student Name: Test User
   - Paper Title: Test Paper
   - Chapter: 1
   - Part: Introduction
   - File: Any PDF

3. **Submit and verify:**
   - Browser should show: "✅ Submission created"
   - Check Supabase Dashboard → Table Editor → submissions (see new row)
   - Check Supabase Dashboard → Storage → research-papers (see PDF)

4. **If it fails:**
   - Press F12 in browser → Console tab
   - Look for error message
   - Compare error with fixes above

---

## Debug Mode

To see detailed logs, add this to server.js:

```javascript
// Add near top of server.js, after dotenv.config()
console.log('🔍 DEBUG: Environment variables');
console.log('   SUPABASE_URL:', process.env.SUPABASE_URL ? '✅' : '❌');
console.log('   SUPABASE_ANON_KEY:', process.env.SUPABASE_ANON_KEY ? '✅' : '❌');
console.log('   SUPABASE_SERVICE_ROLE_KEY:', process.env.SUPABASE_SERVICE_ROLE_KEY ? '✅' : '❌');
```

Then run: `node server.js` and check output

---

## Getting Help

If still stuck, collect this info and share:

1. **Full server output:**
   - Start server and copy all console output
   - Include lines with ✅, ❌, or ERROR

2. **Browser console errors:**
   - Open http://localhost:3000/research-paper-editor.html
   - Press F12 → Console tab
   - Try to upload
   - Copy any error messages

3. **Supabase status:**
   - Verify tables exist in Table Editor (6 tables)
   - Verify bucket exists in Storage
   - Verify bucket is "Public"

4. **Run verification:**
   - node server/verify-setup.js
   - Share the output

---

## Quick Reset (Nuclear Option)

If everything is broken and you want to start fresh:

```powershell
# 1. Stop all Node processes
taskkill /IM node.exe /F

# 2. Clear node_modules and reinstall
cd server
Remove-Item node_modules -Recurse -Force -ErrorAction SilentlyContinue
npm install

# 3. Check .env is correct
Get-Content .env
# (verify SUPABASE_URL and keys are present and correct)

# 4. Try again
node server.js
```

---

**Need more help?**
- Check SUPABASE_FIX_GUIDE.md for full setup instructions
- Check SUPABASE_PROJECT_REFERENCE.md for technical details
- Contact Supabase support at https://supabase.com/support
