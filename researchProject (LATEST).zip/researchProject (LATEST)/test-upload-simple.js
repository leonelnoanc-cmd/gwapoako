#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const http = require('http');

// Create a simple multipart form data manually
const fileContent = fs.readFileSync('C:\\temp\\test.pdf');
const boundary = 'boundary123456789';

const parts = [];
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="student_id"');
parts.push('');
parts.push('test-student-123');
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="student_name"');
parts.push('');
parts.push('Test Student');
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="paper_title"');
parts.push('');
parts.push('Test Paper');
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="chapter"');
parts.push('');
parts.push('1');
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="part"');
parts.push('');
parts.push('Introduction');
parts.push('--' + boundary);
parts.push('Content-Disposition: form-data; name="file"; filename="test.pdf"');
parts.push('Content-Type: application/pdf');
parts.push('');

const header = parts.join('\r\n') + '\r\n';
const footer = '\r\n--' + boundary + '--\r\n';

const body = Buffer.concat([
  Buffer.from(header, 'utf8'),
  fileContent,
  Buffer.from(footer, 'utf8')
]);

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/submissions/upload',
  method: 'POST',
  headers: {
    'Content-Type': 'multipart/form-data; boundary=' + boundary,
    'Content-Length': body.length
  }
};

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('Response:', data);
    process.exit(0);
  });
});

req.on('error', (error) => {
  console.error('Request Error:', error.message);
  console.error('Stack:', error.stack);
  process.exit(1);
});

req.write(body);
req.end();
