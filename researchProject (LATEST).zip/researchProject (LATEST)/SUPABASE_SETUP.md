# Supabase Setup Guide for Research Project

## Step 1: Create Supabase Project (5 minutes)

1. Go to **supabase.com**
2. Click **"Sign Up"** (use email or GitHub)
3. Create a new organization + project
4. Choose region closest to you
5. Wait for project to initialize (~2 min)

---

## Step 2: Get Your API Credentials

After project is created:

1. Go to **Settings** → **API**
2. Copy these values:
   - **Project URL**: `https://xxxx.supabase.co`
   - **anon key**: `eyJ...` (public key)
   - **service_role key**: `eyJ...` (secret key - keep safe!)

Save to `.env`:
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=sb_publishable_zXDoUv_8UPOOm_rSzxNyjg_d_GPDquW
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here   # server only
```

---

## Step 3: Create Database Tables

1. Go to **SQL Editor** in Supabase dashboard
2. Paste the schema from `supabase-schema.sql`
3. Click **Run**

This creates:
- `submissions` table
- `revisions` table
- `timelines` table
- Indexes for fast queries

---

## Step 4: Set Up File Storage Buckets

1. Go to **Storage** in left sidebar
2. Click **Create a new bucket**
3. Name: `research-papers`
4. Make it **Public**
5. Click **Create**

---

## Step 5: Install Supabase Client

In your Node.js server:
```bash
npm install @supabase/supabase-js
```

---

## Step 6: Create Utility Module

Copy `supabase-client.js` to your `server/` directory.

---

## Step 7: Add API Endpoints

Add these endpoints to your server:
- `POST /api/submissions/upload` - Upload paper PDF
- `GET /api/submissions` - Get user submissions
- `PATCH /api/submissions/:id/status` - Update status
- `GET /api/submissions/pending` - Adviser dashboard

See `supabase-endpoints.js` for implementation.

---

## Step 8: Update Frontend

Import file upload module in your HTML:
```html
<script src="supabase-upload.js"></script>
```

---

## Verification

Test with:
```bash
curl -X GET http://localhost:3000/api/submissions \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Expected response:
```json
{
  "data": [
    {
      "id": 1,
      "student_id": "user-123",
      "paper_title": "Chapter 1",
      "file_url": "https://...",
      "status": "pending"
    }
  ]
}
```

---

## Free Tier Limits

- **Storage**: 1 GB
- **Database**: 500 MB
- **Users**: Unlimited
- **API calls**: 2M/month

Your project estimate: ~300 MB (well within limits!)

---

## Next Steps

1. Create Supabase account
2. Add credentials to `.env`
3. Run SQL schema
4. Install npm package
5. Copy utility files
6. Test endpoints

**Questions?** Check `supabase-client.js` for examples.
