# ⚡ SUPABASE QUICK REFERENCE

**Print this card!** Keep it handy while setting up.

---

## 🎯 3-Step Startup

```powershell
# 1. Install dependencies (once)
cd server && npm install

# 2. Start server
node server.js

# 3. Test
Invoke-WebRequest http://localhost:3000/health
```

---

## ✅ Must-Have in Supabase Dashboard

### Tables (6 total - run SQL)
- [ ] submissions
- [ ] revisions  
- [ ] timelines
- [ ] groups
- [ ] group_members
- [ ] notifications

**Where:** SQL Editor → Paste SUPABASE_SCHEMA_READY_TO_COPY.sql → Run

### Storage Bucket
- [ ] Name: research-papers
- [ ] Access: PUBLIC (critical!)

**Where:** Storage → Create Bucket → Settings → Access Control → Public

### Keys (in .env file)
- [ ] SUPABASE_URL
- [ ] SUPABASE_ANON_KEY
- [ ] SUPABASE_SERVICE_ROLE_KEY (rotate if exposed!)
- [ ] PORT=3000

**Where:** https://app.supabase.com → Project wgnbejkryaswxvvhmaff → Settings → API

---

## 📍 Key URLs

| What | URL |
|------|-----|
| Server | http://localhost:3000 |
| Health | http://localhost:3000/health |
| App | http://localhost:3000/research-paper-editor.html |
| Supabase | https://app.supabase.com |
| Your Project | https://app.supabase.com/project/wgnbejkryaswxvvhmaff |

---

## 🆘 Quick Fixes

| Problem | Command |
|---------|---------|
| Port 3000 in use | `taskkill /IM node.exe /F` |
| Deps missing | `npm install` |
| Check setup | `node server/verify-setup.js` |
| Missing modules | `npm install @supabase/supabase-js` |

---

## 🐛 Common Errors

| Error | Fix |
|-------|-----|
| "Table does not exist" | Run SQL schema in Supabase |
| "403 Forbidden" upload | Set bucket to PUBLIC |
| "Port 3000 in use" | Kill node process, see above |
| "Missing SUPABASE_URL" | Check .env exists in root |
| "Invalid API key" | Verify keys in .env match dashboard |

---

## 📋 Setup Checklist

- [ ] npm install (in server/)
- [ ] .env file with credentials
- [ ] 6 database tables created
- [ ] research-papers bucket (PUBLIC)
- [ ] Service key rotated (if exposed)
- [ ] Server starts: node server.js
- [ ] Health check works: /health
- [ ] Upload test succeeds

---

## 🔍 Debug Steps

1. **Is server running?**
   ```powershell
   netstat -ano | findstr 3000
   ```

2. **Can you reach it?**
   ```powershell
   Invoke-WebRequest http://localhost:3000/health
   ```

3. **Check logs** - Watch server.js output

4. **Browser console** - Press F12 on upload page

5. **Supabase logs** - Dashboard → Logs

---

## 📚 Documentation Map

| File | Use For |
|------|---------|
| SUPABASE_FIX_GUIDE.md | Complete setup guide |
| SUPABASE_TROUBLESHOOTING.md | Problem diagnosis |
| SUPABASE_SETUP_MASTER_GUIDE.md | Overview & reference |
| SUPABASE_FINAL_SETUP_GUIDE.md | Manual dashboard steps |
| This Card | Quick lookup |

---

## 🔐 Security Remember

- ✅ Rotate service key if exposed
- ✅ Don't commit .env to git
- ✅ Keep credentials in .env only
- ✅ Public bucket is intentional (for papers)

---

## 💾 Files You Need

```
Project Root/
├── .env                              (create with credentials)
├── server/
│   ├── server.js                     (main server)
│   ├── supabase-client.js           (DB operations)
│   ├── supabase-endpoints.js        (API routes)
│   ├── package.json                 (dependencies)
│   └── node_modules/                (npm install)
├── research-paper-editor.html        (upload page)
├── supabase-upload.js               (frontend module)
└── SUPABASE_SCHEMA_READY_TO_COPY.sql (copy to Supabase)
```

---

## 🎯 Test Procedure

1. **Server running?** → Check logs for ✅ messages
2. **Reach /health?** → Should get 200 response
3. **Visit upload page?** → http://localhost:3000/research-paper-editor.html
4. **Submit PDF?** → Should see "✅ Submission created"
5. **Check Supabase?** → New row in submissions table
6. **Check storage?** → PDF in research-papers bucket

---

## ⏱️ Estimated Setup Time

- Install deps: 2 min
- Create tables: 5 min
- Setup bucket: 3 min
- Rotate key: 5 min
- Start server: 1 min
- Test upload: 5 min
- **Total: ~21 minutes**

---

## 📞 Help Index

| Issue | Page |
|-------|------|
| Server errors | SUPABASE_TROUBLESHOOTING.md |
| Upload fails | SUPABASE_FIX_GUIDE.md Step 6 |
| No tables | SUPABASE_FIX_GUIDE.md Step 1 |
| Port issues | SUPABASE_TROUBLESHOOTING.md |
| Key expired | SUPABASE_FIX_GUIDE.md Step 5 |

---

## 🎓 Key Concepts

- **Supabase:** Postgres + Auth + Storage (BaaS)
- **Express:** Node.js web server framework
- **API:** Routes at http://localhost:3000/api
- **Bucket:** Public cloud storage for PDFs
- **Database:** Tables store submission records
- **.env:** Credentials file (never commit!)

---

## ✨ Success Indicators

✅ Server shows "SERVER STARTED SUCCESSFULLY"
✅ /health returns 200 response
✅ Can access research-paper-editor.html
✅ Upload creates submission in database
✅ PDF appears in storage bucket
✅ No errors in browser console (F12)

---

**READY?** → Start with SUPABASE_FIX_GUIDE.md

**STUCK?** → Check SUPABASE_TROUBLESHOOTING.md

**NEED DETAILS?** → Read SUPABASE_SETUP_MASTER_GUIDE.md

---

Print this! Keep it nearby! Reference it often!

**Last Updated:** January 30, 2026
