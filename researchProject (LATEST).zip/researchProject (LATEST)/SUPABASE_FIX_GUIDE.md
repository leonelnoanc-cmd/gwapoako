# 🔧 Supabase Fix & Recovery Guide

**Date:** January 30, 2026  
**Status:** Critical Issues Found & Solutions Provided

---

## 🚨 Issues Identified

### 1. **Server Dependencies Not Installed**
- `package.json` lists all required dependencies
- But they may not be installed yet
- **Solution:** Run `npm install` in the server directory

### 2. **Server Configuration Issues**
- `.env` file has exposed credentials
- Service role key needs rotation immediately
- **Solution:** Follow rotation steps below

### 3. **Supabase Database Not Set Up**
- Tables may not exist yet in Supabase
- SQL schema needs to be executed manually
- **Solution:** Run SQL schema in Supabase dashboard

### 4. **Storage Bucket May Not Be Public**
- research-papers bucket needs public access
- Without this, file uploads will fail
- **Solution:** Configure bucket permissions

---

## ✅ Complete Fix Checklist

### Step 1: Install Server Dependencies (5 min)

Open PowerShell and run:
```powershell
cd "C:\Users\ADMIN\researchProject (LATEST)\server"
npm install
```

**Expected output:**
```
added XX packages in X.Xs
✓ All dependencies installed
```

---

### Step 2: Test Server Starts (5 min)

```powershell
node server.js
```

**Expected output:**
```
✅ Server running on http://localhost:3000
✅ Supabase endpoints mounted at /api
```

**If it fails:**
- Check if port 3000 is in use: `netstat -ano | findstr 3000`
- Check `.env` file exists and has all values
- Run `npm install` again if it complains about missing modules

---

### Step 3: Verify Supabase Tables Exist (5 min)

**In your browser:**
1. Go to https://app.supabase.com
2. Select project: `wgnbejkryaswxvvhmaff`
3. Click "Table Editor" on left sidebar
4. **Look for these 6 tables:**
   - ☐ submissions
   - ☐ revisions
   - ☐ timelines
   - ☐ groups
   - ☐ group_members
   - ☐ notifications

**If tables are missing:**
1. Click "SQL Editor"
2. Click "New Query"
3. Copy entire content from: `SUPABASE_SCHEMA_READY_TO_COPY.sql`
4. Paste into editor
5. Click "Run"
6. Wait for success message
7. Refresh browser - tables should appear

---

### Step 4: Verify Storage Bucket is Public (3 min)

**In Supabase Dashboard:**
1. Click "Storage" in left sidebar
2. Look for bucket: `research-papers`
3. Click on it
4. Click "Settings" tab
5. Find "Access Control"
6. **MUST be set to: "Public"**
7. If not, change it and click "Save"

---

### Step 5: Rotate Exposed Service Key (SECURITY) (5 min)

Your service role key was exposed. Regenerate it:

1. Go to Supabase Dashboard: https://app.supabase.com
2. Select project: `wgnbejkryaswxvvhmaff`
3. Click ⚙️ "Settings" (bottom-left corner)
4. Click "API" in left menu
5. Find "Service Role Secret" section
6. Click the "Regenerate" button
7. Copy the NEW key (very long string starting with `eyJ...`)
8. Stop the server (Ctrl+C)
9. Update `.env` file:

```env
SUPABASE_URL=https://wgnbejkryaswxvvhmaff.supabase.co
SUPABASE_ANON_KEY=sb_publishable_zXDoUv_8UPOOm_rSzxNyjg_d_GPDquW
SUPABASE_SERVICE_ROLE_KEY=<PASTE_NEW_KEY_HERE>
PORT=3000
```

10. Save the file
11. Restart server: `node server.js`

---

### Step 6: Test Upload Feature (10 min)

**Prerequisites:**
- Server is running
- Tables exist in Supabase
- Bucket is public
- Service key is rotated

**Test:**
1. Open browser: `http://localhost:3000/research-paper-editor.html`
2. Fill form:
   - Student ID: `test-student-123`
   - Student Name: `Test Student`
   - Paper Title: `Test Paper Title`
   - Chapter: `1`
   - Part: `Introduction`
   - Choose any PDF file
3. Click "Submit"

**Success Indicators:**
- ✅ Browser shows: "✅ Submission created"
- ✅ Check Supabase Dashboard → Table Editor → `submissions` → See new row
- ✅ Check Supabase Dashboard → Storage → `research-papers` → See PDF file

**If upload fails:**
- Check browser console: Press F12 → Click "Console"
- Look for error messages
- Compare error with troubleshooting section below

---

## 🐛 Troubleshooting

### Error: "Cannot connect to Supabase"
**Solution:**
1. Check `.env` file exists in project root (NOT in server/ folder)
2. Verify values match Supabase Settings → API
3. Restart server
4. Try again

---

### Error: "Module not found: @supabase/supabase-js"
**Solution:**
```powershell
cd server
npm install @supabase/supabase-js
```

---

### Error: "EADDRINUSE :::3000"
**Port is already in use**
```powershell
# Find process using port 3000
netstat -ano | findstr 3000

# Kill the process (replace XXXX with PID)
taskkill /PID XXXX /F

# Start server again
node server.js
```

---

### Error: "Table does not exist"
**Solution:**
1. Tables weren't created in Supabase
2. Go to Supabase Dashboard → SQL Editor
3. Run the SQL schema
4. Verify tables appear in Table Editor

---

### Error: "403 Forbidden" on file upload
**Solution:**
1. Storage bucket permissions are not set to "Public"
2. Go to Supabase Dashboard → Storage
3. Click bucket → Settings
4. Change "Access Control" to "Public"
5. Click "Save"
6. Try uploading again

---

### Error: "Service role key is invalid"
**Solution:**
1. Key may have expired or been rotated
2. Go to Supabase Dashboard → Settings → API
3. Regenerate new key
4. Update `.env` file
5. Restart server

---

## 📊 Verification Checklist

Use this to verify everything is working:

```
SETUP VERIFICATION CHECKLIST
============================

Database:
  ☐ Supabase project created: wgnbejkryaswxvvhmaff
  ☐ 6 tables created in SQL Editor
  ☐ Tables visible in Table Editor
  ☐ No errors in SQL execution

Storage:
  ☐ Bucket "research-papers" created
  ☐ Bucket set to PUBLIC access level
  ☐ Settings saved

Server:
  ☐ Node.js installed
  ☐ npm install completed in server/
  ☐ .env file configured with credentials
  ☐ Service role key is current (rotated)
  ☐ Server starts without errors

Application:
  ☐ Server runs: node server.js
  ☐ Shows "✅ Supabase endpoints mounted at /api"
  ☐ No port conflicts (port 3000 available)

Testing:
  ☐ Can access http://localhost:3000/research-paper-editor.html
  ☐ Can submit test paper
  ☐ Submission appears in Table Editor
  ☐ PDF appears in Storage bucket
```

---

## 📞 Quick Support

| Problem | Quick Fix |
|---------|-----------|
| Server won't start | Check: port 3000 free, .env exists, npm install done |
| Upload fails | Check: bucket is PUBLIC, tables exist, credentials correct |
| Can't see tables | Check: SQL executed, no errors, refresh browser |
| File not uploading | Check: server running, bucket public, file is PDF |
| Connection error | Check: .env has SUPABASE_URL and SERVICE_ROLE_KEY |

---

## 🔐 Security Notes

⚠️ **Your credentials were exposed in documentation!**

After completing this guide:
1. ✅ Service role key MUST be rotated (see Step 5)
2. ✅ `.env` file MUST NOT be committed to git
3. ✅ Check `.gitignore` includes `.env`
4. ✅ Never share credentials in chat or documentation

---

## ✨ Next Steps After Verification

Once all tests pass:

1. **Integrate into Your Pages**
   - Add upload forms to HTML pages
   - Use `supabase-upload.js` module

2. **Connect Dashboards**
   - Display submissions in student/adviser dashboards
   - Show revision workflow

3. **Monitor Usage**
   - Check Supabase Analytics for performance
   - Monitor storage usage

---

**Status:** Ready for manual configuration and testing  
**Last Updated:** January 30, 2026
