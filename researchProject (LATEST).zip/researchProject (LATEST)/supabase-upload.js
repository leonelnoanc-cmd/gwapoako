/**
 * Supabase File Upload Module
 * Frontend utility for uploading papers to Supabase
 * 
 * Usage:
 * const uploader = new PaperUploader('YOUR_API_SERVER_URL');
 * await uploader.uploadPaper(file, metadata);
 */

class PaperUploader {
  constructor(apiServerUrl) {
    this.apiServerUrl = apiServerUrl || window.API_SERVER_URL || 'http://localhost:3000';
  }

  /**
   * Upload a paper file
   * @param {File} file - PDF file from input
   * @param {Object} metadata - Paper metadata
   * @returns {Promise<Object>} - Upload result with file URL
   */
  async uploadPaper(file, metadata) {
    try {
      // Validate file
      if (!file || file.type !== 'application/pdf') {
        throw new Error('Please select a valid PDF file');
      }

      if (file.size > 50 * 1024 * 1024) {
        throw new Error('File is too large (max 50MB)');
      }

      // Validate metadata
      if (!metadata.student_id || !metadata.paper_title || !metadata.chapter || !metadata.part) {
        throw new Error('Missing required metadata fields');
      }

      // Show progress
      console.log('Uploading paper:', file.name);

      // Create FormData
      const formData = new FormData();
      formData.append('file', file);
      formData.append('student_id', metadata.student_id);
      formData.append('student_name', metadata.student_name || 'Unknown');
      formData.append('paper_title', metadata.paper_title);
      formData.append('chapter', metadata.chapter);
      formData.append('part', metadata.part);

      // Upload to server
      const response = await fetch(`${this.apiServerUrl}/api/submissions/upload`, {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
        }
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Upload failed');
      }

      const result = await response.json();
      console.log('Upload successful:', result);

      return {
        success: true,
        message: 'Paper uploaded successfully',
        submission: result.submission,
        fileUrl: result.submission.file_url
      };
    } catch (error) {
      console.error('Upload error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Get student's submissions
   */
  async getSubmissions(studentId) {
    try {
      const response = await fetch(
        `${this.apiServerUrl}/api/submissions/${studentId}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          }
        }
      );

      if (!response.ok) throw new Error('Failed to fetch submissions');
      return await response.json();
    } catch (error) {
      console.error('Get submissions error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get pending submissions (adviser)
   */
  async getPendingSubmissions() {
    try {
      const response = await fetch(
        `${this.apiServerUrl}/api/submissions-pending/all`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          }
        }
      );

      if (!response.ok) throw new Error('Failed to fetch submissions');
      return await response.json();
    } catch (error) {
      console.error('Get pending error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Update submission status
   */
  async updateStatus(submissionId, status) {
    try {
      const response = await fetch(
        `${this.apiServerUrl}/api/submissions/${submissionId}/status`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          },
          body: JSON.stringify({ status })
        }
      );

      if (!response.ok) throw new Error('Failed to update status');
      return await response.json();
    } catch (error) {
      console.error('Update status error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Request a revision
   */
  async requestRevision(submissionId, feedback) {
    try {
      const response = await fetch(
        `${this.apiServerUrl}/api/revisions/${submissionId}/request`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          },
          body: JSON.stringify({ feedback })
        }
      );

      if (!response.ok) throw new Error('Failed to request revision');
      return await response.json();
    } catch (error) {
      console.error('Request revision error:', error);
      return { success: false, error: error.message };
    }
  }
}

// Usage Example:
// ============
// 
// HTML:
// <input type="file" id="paperInput" accept=".pdf">
// <button onclick="uploadPaper()">Upload</button>
//
// JavaScript:
// const uploader = new PaperUploader();
//
// async function uploadPaper() {
//   const file = document.getElementById('paperInput').files[0];
//   const result = await uploader.uploadPaper(file, {
//     student_id: 'student-123',
//     student_name: 'John Doe',
//     paper_title: 'Introduction',
//     chapter: 1,
//     part: 'Background of the Study'
//   });
//
//   if (result.success) {
//     alert('Upload successful!');
//     console.log('File URL:', result.fileUrl);
//   } else {
//     alert('Error: ' + result.error);
//   }
// }
