# Draft Submission & Notification System Implementation

## Overview
This implementation adds a complete draft submission system where students can submit drafts to their adviser, notifications are triggered, and groups can auto-submit when all members have submitted their drafts.

## Features Implemented

### 1. **Student Draft Submission (draft.html)**
- Added a new "📤 Submit Draft" button in the footer
- `submitDraft()` function that:
  - Validates draft content exists
  - Collects all submitted items and references
  - Creates a draft submission object with metadata
  - Saves to `adviserDraftSubmissions` localStorage
  - Creates a notification for the adviser
  - Automatically checks if group should be auto-submitted (for leaders)

### 2. **Adviser Notifications System**
- Notifications stored in `adviserNotifications` localStorage
- Contains notification metadata:
  - `id`: Unique notification ID
  - `type`: 'draft_submission' or 'group_draft_submission'
  - `studentName` / `groupName`: Who submitted
  - `message`: Human-readable message
  - `submittedAt`: Timestamp
  - `read`: Boolean for read status
  - `draftData`: Complete submission data

### 3. **Draft Submission Storage Structure**

#### Student Draft Submission
```json
{
  "id": 1234567890,
  "submittedBy": "John Doe",
  "userRole": "student",
  "submittedAt": "2026-01-20T10:30:00.000Z",
  "items": [
    {
      "chapter": "1",
      "part": "Background of the Study",
      "content": "..."
    }
  ],
  "references": "[...]",
  "isDraft": true,
  "status": "submitted"
}
```

#### Group Draft Submission (Auto-submitted)
```json
{
  "id": 1234567890,
  "groupName": "Group 1",
  "groupId": 987654,
  "sectionName": "Section A",
  "members": ["John Doe", "Jane Smith"],
  "submittedAt": "2026-01-20T10:30:00.000Z",
  "isGroupSubmission": true,
  "status": "submitted"
}
```

### 4. **Group Auto-Submit Logic**
When a student-leader submits a draft:
- `checkAndAutoSubmitGroup()` is called
- Checks if all group members have submitted drafts
- If YES: Auto-submits group with `submitGroupDraft()`
- Creates a group submission record
- Creates a group submission notification

### 5. **Adviser Dashboard - Draft Submissions Page**
New page: `adviser-draft-submissions.html`

Features:
- Tab-based view: Student Drafts | Group Drafts
- Each draft displayed as a card showing:
  - Student/Group name
  - Submission date/time
  - Number of chapter parts
  - Number of references
  - Status badge
- Actions available:
  - 👁️ View Draft: See full submission details
  - ✓ Approve: Approve the draft submission

### 6. **Adviser Dashboard Updates**
- Added new sidebar icon for "📤 Drafts"
- Clicking Drafts takes to `adviser-draft-submissions.html`
- Shows notification count of pending drafts

## localStorage Keys Used

### New Keys:
- `adviserDraftSubmissions`: Array of all student draft submissions
- `adviserNotifications`: Array of all notifications for adviser
- `groupDraftSubmissions`: Array of group draft submissions

### Existing Keys Modified:
- None modified, only new keys added

## User Flow

### Student Flow:
1. Student creates paper in editor
2. Student clicks "Submit Draft" button on draft.html
3. System validates content exists
4. Draft is saved to adviser's dashboard
5. Notification is sent to adviser
6. If student-leader, group auto-submits if all members have submitted

### Adviser Flow:
1. Adviser receives notifications when drafts are submitted
2. Adviser can click "📤 Drafts" in sidebar
3. Adviser views all student and group drafts
4. Adviser can "View Draft" to see full content
5. Adviser can "Approve" draft
6. Draft status changes to "approved"

## Integration Points

### With Existing System:
- Retrieves `userRole` from localStorage
- Retrieves logged-in user from `loggedInUser`
- Retrieves current section from `currentSection`
- Retrieves current group from `currentGroup`
- Retrieves group members from `currentGroup.members`
- Uses existing submission format from `submissions` storage

### With Adviser Dashboard:
- Adviser can access drafts from sidebar
- Drafts page shows pending and approved submissions
- Notifications system ready for future enhancements

## Future Enhancements

1. **Notification Display**: Add notification bell/counter in adviser header
2. **Draft Comments**: Allow adviser to add comments before approval
3. **Revision Requests**: Allow adviser to request revisions
4. **Email Integration**: Send email notifications to adviser
5. **Draft History**: Track version history of drafts
6. **Draft Preview**: Full modal/page to view complete draft content
7. **Group Member Status**: Show which members have/haven't submitted in group drafts

## Error Handling

- Checks for missing content before submission
- Validates user role and group membership
- Error logging for debugging
- Graceful fallbacks for missing data

## Code Quality

- Consistent naming conventions
- Proper error handling with try-catch
- Clear console logging for debugging
- Modular function structure
- Comments for complex logic
