# Adviser Notification System Documentation

## Overview
The adviser notification system is a localStorage-based notification engine that tracks all student and group draft submissions, with metadata about who submitted, when, and what was submitted.

## Architecture

### Three-Tier Storage System

```
┌─────────────────────────────────────────────────────┐
│            Browser localStorage                     │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌───────────────────┐                              │
│  │ adviserNotifications│  ← Main notification log   │
│  │ (All notifications) │                            │
│  └───────────────────┘                              │
│           ↓                                          │
│  ┌───────────────────────────────┐                  │
│  │ adviserDraftSubmissions       │ ← Student drafts │
│  │ (Details of each student draft)│               │
│  └───────────────────────────────┘                  │
│           ↓                                          │
│  ┌───────────────────────────────┐                  │
│  │ groupDraftSubmissions         │ ← Group drafts  │
│  │ (Auto-submitted group drafts) │                │
│  └───────────────────────────────┘                  │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Data Structures

### 1. Notification Object
```javascript
{
  id: number,              // Unique timestamp-based ID
  type: string,            // 'draft_submission' | 'group_draft_submission'
  studentName: string,     // Name of student (null for group)
  groupName: string,       // Name of group (null for student)
  message: string,         // Human-readable message
  submittedAt: string,     // ISO timestamp
  draftData: object,       // Full submission object
  read: boolean            // Notification read status
}
```

### 2. Draft Submission Object (Student)
```javascript
{
  id: number,              // Unique ID
  submittedBy: string,     // Student name
  userRole: string,        // 'student' | 'student-leader'
  submittedAt: string,     // ISO timestamp
  items: [                 // Array of chapter parts
    {
      chapter: string,     // '1', '2', '3', etc.
      part: string,        // Part name
      content: string      // HTML content
    }
  ],
  references: string,      // JSON stringified array
  isDraft: boolean,        // Always true for draft
  status: string           // 'submitted' | 'approved'
}
```

### 3. Draft Submission Object (Group Auto-Submit)
```javascript
{
  id: number,              // Unique ID
  groupName: string,       // Group name
  groupId: number,         // Group ID
  sectionName: string,     // Section name
  members: [string],       // Array of member names
  submittedAt: string,     // ISO timestamp
  isGroupSubmission: boolean, // Always true
  status: string           // 'submitted' | 'approved'
}
```

## Notification Types

### Type 1: Student Draft Submission
**When:** Student clicks "📤 Submit Draft" button
**Message Pattern:** `"{studentName} has submitted a draft with {count} chapter parts."`
**Includes:** Full draft submission data
**Example:**
```javascript
{
  type: 'draft_submission',
  studentName: 'John Doe',
  message: 'John Doe has submitted a draft with 5 chapter parts.'
}
```

### Type 2: Group Draft Auto-Submission
**When:** Last group member submits draft (all members complete)
**Message Pattern:** `"Group \"{groupName}\" has submitted their complete draft. All {count} members have submitted their work."`
**Includes:** Full group submission data with member list
**Example:**
```javascript
{
  type: 'group_draft_submission',
  groupName: 'Group 1',
  message: 'Group "Group 1" has submitted their complete draft. All 3 members have submitted their work.'
}
```

## Implementation Details

### Student Draft Submission Flow

```javascript
// In draft.html
function submitDraft() {
  // 1. Validate content
  if (!submissions || submissions.length === 0) {
    alert('⚠️ No draft content to submit...');
    return;
  }

  // 2. Collect data
  const draftSubmission = {
    id: Date.now(),
    submittedBy: submittedBy,
    userRole: userRole,
    submittedAt: new Date().toISOString(),
    items: [],              // Populated with chapter items
    references: JSON.stringify(allReferences),
    isDraft: true,
    status: 'submitted'
  };

  // 3. Save draft
  const adviserDraftSubmissions = JSON.parse(
    localStorage.getItem('adviserDraftSubmissions') || '[]'
  );
  adviserDraftSubmissions.push(draftSubmission);
  localStorage.setItem('adviserDraftSubmissions', 
    JSON.stringify(adviserDraftSubmissions));

  // 4. Create notification
  const adviserNotifications = JSON.parse(
    localStorage.getItem('adviserNotifications') || '[]'
  );
  adviserNotifications.push({
    id: Date.now(),
    type: 'draft_submission',
    studentName: submittedBy,
    message: `${submittedBy} has submitted a draft with ${draftSubmission.items.length} chapter parts.`,
    submittedAt: new Date().toISOString(),
    draftData: draftSubmission,
    read: false
  });
  localStorage.setItem('adviserNotifications', 
    JSON.stringify(adviserNotifications));

  // 5. Check group auto-submit
  if (userRole === 'student-leader') {
    checkAndAutoSubmitGroup();
  }
}
```

### Group Auto-Submit Flow

```javascript
// In draft.html
function checkAndAutoSubmitGroup() {
  // 1. Get current group context
  const currentGroup = JSON.parse(
    localStorage.getItem('currentGroup') || '{}'
  );
  const members = currentGroup.members || [];

  // 2. Get all draft submissions
  const adviserDraftSubmissions = JSON.parse(
    localStorage.getItem('adviserDraftSubmissions') || '[]'
  );

  // 3. Check if all members have submitted
  const allSubmitted = members.every(member => 
    adviserDraftSubmissions.some(d => d.submittedBy === member)
  );

  // 4. If all submitted, auto-submit group
  if (allSubmitted && members.length > 0) {
    submitGroupDraft(group, sectionName);
  }
}

function submitGroupDraft(group, sectionName) {
  // 1. Create group submission
  const groupDraftSubmission = {
    id: Date.now(),
    groupName: group.name,
    groupId: group.id,
    sectionName: sectionName,
    members: group.members || [],
    submittedAt: new Date().toISOString(),
    isGroupSubmission: true,
    status: 'submitted'
  };

  // 2. Save group submission
  const groupSubmissions = JSON.parse(
    localStorage.getItem('groupDraftSubmissions') || '[]'
  );
  groupSubmissions.push(groupDraftSubmission);
  localStorage.setItem('groupDraftSubmissions', 
    JSON.stringify(groupSubmissions));

  // 3. Create notification for adviser
  const adviserNotifications = JSON.parse(
    localStorage.getItem('adviserNotifications') || '[]'
  );
  adviserNotifications.push({
    id: Date.now(),
    type: 'group_draft_submission',
    groupName: group.name,
    message: `Group "${group.name}" has submitted their complete draft. All ${group.members.length} members have submitted their work.`,
    submittedAt: new Date().toISOString(),
    groupData: groupDraftSubmission,
    read: false
  });
  localStorage.setItem('adviserNotifications', 
    JSON.stringify(adviserNotifications));
}
```

## Reading Notifications

### Get All Notifications
```javascript
const allNotifications = JSON.parse(
  localStorage.getItem('adviserNotifications') || '[]'
);
// Returns array of all notifications
```

### Get Unread Notifications
```javascript
const unreadNotifications = JSON.parse(
  localStorage.getItem('adviserNotifications') || '[]'
).filter(n => !n.read);
// Returns only unread notifications
```

### Get Notifications by Type
```javascript
const draftNotifications = JSON.parse(
  localStorage.getItem('adviserNotifications') || '[]'
).filter(n => n.type === 'draft_submission');

const groupNotifications = JSON.parse(
  localStorage.getItem('adviserNotifications') || '[]'
).filter(n => n.type === 'group_draft_submission');
```

### Mark Notification as Read
```javascript
const notifications = JSON.parse(
  localStorage.getItem('adviserNotifications') || '[]'
);
const notificationIndex = notifications.findIndex(n => n.id === notificationId);
if (notificationIndex !== -1) {
  notifications[notificationIndex].read = true;
  localStorage.setItem('adviserNotifications', 
    JSON.stringify(notifications));
}
```

## Display in Adviser Dashboard

### Current Implementation
Located in `adviser-draft-submissions.html`:
- Tab-based view for Student Drafts and Group Drafts
- Cards for each submission
- View and Approve buttons
- Status indicators

### Future Enhancements
- Notification bell in header with counter
- Toast notifications when new draft submitted
- Real-time updates using WebSocket
- Email notifications
- Notification history/archive

## Error Handling

### Try-Catch Blocks
All operations are wrapped in try-catch to handle:
- Invalid JSON parsing
- Missing localStorage data
- Undefined references

```javascript
try {
  // Operation
} catch (e) {
  console.error('Error:', e);
  // Graceful fallback
}
```

### Fallback Values
```javascript
// Returns empty array if key doesn't exist
const data = JSON.parse(
  localStorage.getItem('key') || '[]'
);
```

## Debugging

### View All Notifications (Browser Console)
```javascript
JSON.parse(localStorage.getItem('adviserNotifications') || '[]')
```

### View Student Drafts
```javascript
JSON.parse(localStorage.getItem('adviserDraftSubmissions') || '[]')
```

### View Group Drafts
```javascript
JSON.parse(localStorage.getItem('groupDraftSubmissions') || '[]')
```

### Clear All Notifications (Warning: Destructive)
```javascript
localStorage.removeItem('adviserNotifications');
localStorage.removeItem('adviserDraftSubmissions');
localStorage.removeItem('groupDraftSubmissions');
```

## Performance Considerations

- **Storage Limit**: localStorage typically ~5-10MB (usually sufficient)
- **Array Operations**: Filtering/searching done on client-side
- **No Pagination**: All data loaded at once (may need pagination for large datasets)

## Scalability

For production deployment:
1. Move to database instead of localStorage
2. Implement server-side notification service
3. Add real-time WebSocket support
4. Implement notification pagination
5. Archive old notifications

## API Endpoints (Recommended for Production)

```
GET /api/notifications              - Get all notifications
GET /api/notifications/unread       - Get unread only
GET /api/notifications/:id          - Get specific notification
POST /api/notifications/:id/read    - Mark as read
DELETE /api/notifications/:id       - Delete notification
GET /api/drafts                     - Get all draft submissions
GET /api/drafts/:id                 - Get specific draft
PATCH /api/drafts/:id/approve       - Approve draft
```

## Testing Scenarios

### Scenario 1: Single Student Submit
1. Student submits draft
2. Check `adviserNotifications` contains notification
3. Check `adviserDraftSubmissions` contains submission
4. Verify adviser can see it in dashboard

### Scenario 2: Group Auto-Submit
1. Create group with 2 members
2. Member 1 submits draft
3. Check only individual notification
4. Member 2 submits draft
5. Check group notification created
6. Verify group submission auto-created

### Scenario 3: Approval Workflow
1. Adviser views draft
2. Click Approve
3. Verify status changes to "approved"
4. Verify timestamp recorded
5. Verify read status updates

## Maintenance

### Regular Cleanup (Recommended)
- Archive approved drafts after 30 days
- Delete notification history after 90 days
- Compress old data for archival

### Monitoring
- Monitor localStorage usage
- Track notification volume
- Monitor submission patterns
