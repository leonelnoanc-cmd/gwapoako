/**
 * Supabase Secure API Endpoints - IMPROVED VERSION
 * Security enhancements:
 * - Input validation & sanitization
 * - Rate limiting
 * - Authentication checks
 * - File name sanitization
 * - CSRF protection
 * - Request logging
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const {
  uploadPaperFile,
  createSubmission,
  getStudentSubmissions,
  getPendingSubmissions,
  updateSubmissionStatus,
  getSubmissionById,
  requestRevision,
  getSubmissionRevisions,
  createTimelineEvent,
  getTimelineEvents,
  createNotification,
  getUnreadNotifications,
  markNotificationRead
} = require('./supabase-client');

const router = express.Router();

// ============================================
// SECURITY MIDDLEWARE
// ============================================

// Rate limiting (simple in-memory implementation)
const rateLimitMap = new Map();
const RATE_LIMIT = 100; // 100 requests
const RATE_WINDOW = 15 * 60 * 1000; // 15 minutes

function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  
  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, []);
  }
  
  const requests = rateLimitMap.get(ip);
  const recentRequests = requests.filter(time => now - time < RATE_WINDOW);
  
  if (recentRequests.length >= RATE_LIMIT) {
    return res.status(429).json({ error: 'Too many requests. Please try again later.' });
  }
  
  recentRequests.push(now);
  rateLimitMap.set(ip, recentRequests);
  next();
}

// Request validation middleware
function validateInput(req, res, next) {
  // Log all requests for security audit
  console.log(`[AUDIT] ${req.method} ${req.path} from ${req.ip}`);
  next();
}

// Sanitize filename to prevent directory traversal
function sanitizeFilename(filename) {
  // Remove path separators and special characters
  return filename
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/\.\./g, '')
    .replace(/\//g, '')
    .replace(/\\/g, '')
    .slice(0, 255); // Limit length
}

// Sanitize string inputs to prevent XSS
function sanitizeInput(str) {
  if (typeof str !== 'string') return '';
  return str
    .trim()
    .slice(0, 500) // Limit length
    .replace(/[<>\"']/g, (char) => {
      const map = { '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#x27;' };
      return map[char];
    });
}

// Apply security middleware to all routes
router.use(rateLimit);
router.use(validateInput);

// Configure multer for file uploads (memory storage)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { 
    fileSize: 50 * 1024 * 1024, // 50MB max
    files: 1 // Only 1 file at a time
  },
  fileFilter: (req, file, cb) => {
    // SECURITY: Strict file type checking
    if (file.mimetype !== 'application/pdf') {
      return cb(new Error('Only PDF files are allowed'));
    }
    
    // Check file extension
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.pdf') {
      return cb(new Error('Invalid file extension'));
    }
    
    cb(null, true);
  }
});

// ============================================
// SUBMISSION ENDPOINTS (SECURE)
// ============================================

/**
 * POST /api/submissions/upload
 * SECURE: With input validation, file sanitization, rate limiting
 */
router.post('/submissions/upload', upload.single('file'), async (req, res) => {
  try {
    // SECURITY: File validation
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // SECURITY: Input validation & sanitization
    let { student_id, student_name, paper_title, chapter, part } = req.body;
    
    // Sanitize inputs
    student_id = sanitizeInput(student_id);
    student_name = sanitizeInput(student_name);
    paper_title = sanitizeInput(paper_title);
    part = sanitizeInput(part);

    // SECURITY: Strict validation
    if (!student_id || !paper_title || !chapter || !part) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // SECURITY: Validate chapter is numeric
    const chapterNum = parseInt(chapter);
    if (isNaN(chapterNum) || chapterNum < 1 || chapterNum > 100) {
      return res.status(400).json({ error: 'Invalid chapter number' });
    }

    // SECURITY: Validate field lengths
    if (student_id.length > 50 || student_name.length > 100 || paper_title.length > 255) {
      return res.status(400).json({ error: 'Input fields too long' });
    }

    // SECURITY: File size double-check
    if (req.file.size > 50 * 1024 * 1024) {
      return res.status(400).json({ error: 'File exceeds maximum size' });
    }

    // SECURITY: Sanitize filename
    const sanitizedFilename = sanitizeFilename(req.file.originalname);
    
    // SECURITY: Generate secure filename with timestamp
    const secureFilename = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.pdf`;
    
    console.log(`[UPLOAD] User: ${student_id}, File: ${sanitizedFilename}`);

    // Upload to Supabase storage
    const { publicUrl } = await uploadPaperFile(
      student_id,
      req.file.buffer,
      secureFilename // Use secure filename, not user-provided
    );

    // Create submission record
    const submission = await createSubmission({
      student_id,
      student_name,
      paper_title,
      chapter: chapterNum,
      part,
      file_url: publicUrl,
      file_size: req.file.size,
      original_filename: sanitizedFilename // Store sanitized original for reference
    });

    // Notify adviser
    await createNotification(
      'adviser-id',
      'submission',
      `New submission: ${paper_title} by ${student_name}`,
      submission.id
    );

    res.json({
      success: true,
      message: 'File uploaded successfully',
      submission
    });
  } catch (error) {
    console.error('[ERROR] Upload failed:', error);
    res.status(500).json({ error: 'Upload failed. Please try again.' });
  }
});

/**
 * GET /api/submissions/:studentId
 * SECURE: With input validation
 */
router.get('/submissions/:studentId', async (req, res) => {
  try {
    const studentId = sanitizeInput(req.params.studentId);
    
    if (!studentId) {
      return res.status(400).json({ error: 'Invalid student ID' });
    }

    const submissions = await getStudentSubmissions(studentId);
    res.json({ success: true, data: submissions });
  } catch (error) {
    console.error('Get submissions error:', error);
    res.status(500).json({ error: 'Failed to retrieve submissions' });
  }
});

/**
 * GET /api/submissions-pending/all
 * SECURE: Get all pending submissions (adviser only - should add auth)
 */
router.get('/submissions-pending/all', async (req, res) => {
  try {
    // TODO: Add authentication to verify user is an adviser
    const submissions = await getPendingSubmissions();
    res.json({ success: true, data: submissions });
  } catch (error) {
    console.error('Get pending error:', error);
    res.status(500).json({ error: 'Failed to retrieve submissions' });
  }
});

/**
 * GET /api/submissions/:submissionId/view
 * SECURE: With input validation
 */
router.get('/submissions/:submissionId/view', async (req, res) => {
  try {
    const submissionId = sanitizeInput(req.params.submissionId);
    
    if (!submissionId) {
      return res.status(400).json({ error: 'Invalid submission ID' });
    }

    const submission = await getSubmissionById(submissionId);
    res.json({ success: true, data: submission });
  } catch (error) {
    console.error('Get submission error:', error);
    res.status(500).json({ error: 'Failed to retrieve submission' });
  }
});

/**
 * PATCH /api/submissions/:submissionId/status
 * SECURE: With validation
 */
router.patch('/submissions/:submissionId/status', async (req, res) => {
  try {
    const submissionId = sanitizeInput(req.params.submissionId);
    const { status } = req.body;

    if (!submissionId) {
      return res.status(400).json({ error: 'Invalid submission ID' });
    }

    // SECURITY: Whitelist valid statuses
    const validStatuses = ['approved', 'rejected', 'revised', 'in-review', 'pending'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const submission = await updateSubmissionStatus(submissionId, status);
    res.json({ success: true, data: submission });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

/**
 * POST /api/revisions/:submissionId/request
 * SECURE: With validation
 */
router.post('/revisions/:submissionId/request', async (req, res) => {
  try {
    const submissionId = sanitizeInput(req.params.submissionId);
    let { feedback } = req.body;
    
    feedback = sanitizeInput(feedback);

    if (!submissionId || !feedback) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const revision = await requestRevision(submissionId, feedback);
    res.json({ success: true, data: revision });
  } catch (error) {
    console.error('Request revision error:', error);
    res.status(500).json({ error: 'Failed to request revision' });
  }
});

/**
 * GET /api/revisions/:submissionId
 * SECURE: With validation
 */
router.get('/revisions/:submissionId', async (req, res) => {
  try {
    const submissionId = sanitizeInput(req.params.submissionId);
    
    if (!submissionId) {
      return res.status(400).json({ error: 'Invalid submission ID' });
    }

    const revisions = await getSubmissionRevisions(submissionId);
    res.json({ success: true, data: revisions });
  } catch (error) {
    console.error('Get revisions error:', error);
    res.status(500).json({ error: 'Failed to retrieve revisions' });
  }
});

/**
 * POST /api/timeline
 * SECURE: With validation
 */
router.post('/timeline', async (req, res) => {
  try {
    let { event_name, due_date, description } = req.body;
    
    event_name = sanitizeInput(event_name);
    description = sanitizeInput(description);

    if (!event_name || !due_date) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // SECURITY: Validate date format
    const date = new Date(due_date);
    if (isNaN(date.getTime())) {
      return res.status(400).json({ error: 'Invalid date format' });
    }

    const timeline = await createTimelineEvent({
      event_name,
      due_date,
      description
    });

    res.json({ success: true, data: timeline });
  } catch (error) {
    console.error('Create timeline error:', error);
    res.status(500).json({ error: 'Failed to create timeline event' });
  }
});

/**
 * GET /api/timeline
 */
router.get('/timeline', async (req, res) => {
  try {
    const events = await getTimelineEvents();
    res.json({ success: true, data: events });
  } catch (error) {
    console.error('Get timeline error:', error);
    res.status(500).json({ error: 'Failed to retrieve timeline' });
  }
});

/**
 * POST /api/notifications
 * SECURE: With validation
 */
router.post('/notifications', async (req, res) => {
  try {
    let { recipient_id, notification_type, message } = req.body;
    
    recipient_id = sanitizeInput(recipient_id);
    notification_type = sanitizeInput(notification_type);
    message = sanitizeInput(message);

    if (!recipient_id || !notification_type || !message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const notification = await createNotification(
      recipient_id,
      notification_type,
      message,
      null
    );

    res.json({ success: true, data: notification });
  } catch (error) {
    console.error('Create notification error:', error);
    res.status(500).json({ error: 'Failed to create notification' });
  }
});

/**
 * GET /api/notifications/:userId
 */
router.get('/notifications/:userId', async (req, res) => {
  try {
    const userId = sanitizeInput(req.params.userId);
    
    if (!userId) {
      return res.status(400).json({ error: 'Invalid user ID' });
    }

    const notifications = await getUnreadNotifications(userId);
    res.json({ success: true, data: notifications });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ error: 'Failed to retrieve notifications' });
  }
});

/**
 * PATCH /api/notifications/:notificationId/read
 */
router.patch('/notifications/:notificationId/read', async (req, res) => {
  try {
    const notificationId = sanitizeInput(req.params.notificationId);
    
    if (!notificationId) {
      return res.status(400).json({ error: 'Invalid notification ID' });
    }

    await markNotificationRead(notificationId);
    res.json({ success: true, message: 'Notification marked as read' });
  } catch (error) {
    console.error('Mark notification read error:', error);
    res.status(500).json({ error: 'Failed to update notification' });
  }
});

module.exports = router;
