#!/usr/bin/env node

/**
 * Supabase Setup Verification & Initialization Script
 * Run this to check if Supabase is properly configured
 */

const path = require('path');
const fs = require('fs');

console.log('\n🔍 SUPABASE SETUP VERIFICATION\n');
console.log('=' .repeat(60));

// 1. Check environment file
console.log('\n1️⃣  Checking environment configuration...');
const envPath = path.join(__dirname, '..', '.env');
if (fs.existsSync(envPath)) {
  console.log('   ✅ .env file found');
  
  const envContent = fs.readFileSync(envPath, 'utf8');
  const hasUrl = envContent.includes('SUPABASE_URL');
  const hasAnonKey = envContent.includes('SUPABASE_ANON_KEY');
  const hasServiceKey = envContent.includes('SUPABASE_SERVICE_ROLE_KEY');
  
  console.log(`   ${hasUrl ? '✅' : '❌'} SUPABASE_URL present`);
  console.log(`   ${hasAnonKey ? '✅' : '❌'} SUPABASE_ANON_KEY present`);
  console.log(`   ${hasServiceKey ? '✅' : '❌'} SUPABASE_SERVICE_ROLE_KEY present`);
  
  if (!hasUrl || !hasAnonKey || !hasServiceKey) {
    console.log('\n   ⚠️  Missing required environment variables!');
    console.log('   See .env.example for the template.');
  }
} else {
  console.log('   ❌ .env file NOT found');
  console.log('   📝 Create .env file with required credentials');
}

// 2. Check dependencies
console.log('\n2️⃣  Checking dependencies...');
const packageJsonPath = path.join(__dirname, 'package.json');
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));

const requiredDeps = [
  '@supabase/supabase-js',
  'express',
  'cors',
  'multer',
  'dotenv'
];

let allDepsPresent = true;
requiredDeps.forEach(dep => {
  const isPresent = packageJson.dependencies[dep];
  console.log(`   ${isPresent ? '✅' : '❌'} ${dep}`);
  if (!isPresent) allDepsPresent = false;
});

if (!allDepsPresent) {
  console.log('\n   ⚠️  Some dependencies are missing!');
  console.log('   Run: npm install');
}

// 3. Check if node_modules exists
console.log('\n3️⃣  Checking if dependencies are installed...');
const nodeModulesPath = path.join(__dirname, 'node_modules');
if (fs.existsSync(nodeModulesPath)) {
  console.log('   ✅ node_modules found');
  
  const supabaseModulePath = path.join(nodeModulesPath, '@supabase', 'supabase-js');
  if (fs.existsSync(supabaseModulePath)) {
    console.log('   ✅ @supabase/supabase-js installed');
  } else {
    console.log('   ❌ @supabase/supabase-js NOT installed');
    console.log('   Run: npm install');
  }
} else {
  console.log('   ❌ node_modules NOT found');
  console.log('   Run: npm install');
}

// 4. Check server files
console.log('\n4️⃣  Checking required server files...');
const requiredFiles = [
  'server.js',
  'supabase-client.js',
  'supabase-endpoints.js'
];

requiredFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  const exists = fs.existsSync(filePath);
  console.log(`   ${exists ? '✅' : '❌'} ${file}`);
});

// 5. Test Supabase connection (if credentials present)
console.log('\n5️⃣  Testing Supabase connection...');
if (fs.existsSync(envPath)) {
  try {
    require('dotenv').config({ path: envPath });
    
    if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) {
      try {
        const { createClient } = require('@supabase/supabase-js');
        const supabase = createClient(
          process.env.SUPABASE_URL,
          process.env.SUPABASE_SERVICE_ROLE_KEY
        );
        console.log('   ✅ Supabase client initialized');
        console.log(`   📍 Project URL: ${process.env.SUPABASE_URL}`);
        
        // Try to list tables
        supabase.from('submissions').select('count', { count: 'exact', head: true })
          .then(response => {
            if (response.error && response.error.code === '42P01') {
              console.log('   ⚠️  Table "submissions" does NOT exist');
              console.log('   📝 You need to run the SQL schema in Supabase Dashboard');
            } else if (response.error) {
              console.log(`   ⚠️  Connection error: ${response.error.message}`);
            } else {
              console.log('   ✅ Database table "submissions" exists');
            }
          })
          .catch(err => {
            console.log(`   ⚠️  Connection test error: ${err.message}`);
          });
      } catch (err) {
        console.log(`   ❌ Failed to create Supabase client: ${err.message}`);
        console.log('   📝 Make sure @supabase/supabase-js is installed: npm install');
      }
    } else {
      console.log('   ❌ Supabase credentials not found in .env');
    }
  } catch (err) {
    console.log(`   ❌ Error: ${err.message}`);
  }
} else {
  console.log('   ⏭️  Skipped (.env file not found)');
}

// 6. Summary and next steps
console.log('\n' + '='.repeat(60));
console.log('\n📋 SETUP SUMMARY\n');

let readyToStart = true;

if (!fs.existsSync(envPath)) {
  console.log('❌ BLOCKING: Create .env file with Supabase credentials');
  readyToStart = false;
}

if (!fs.existsSync(nodeModulesPath)) {
  console.log('❌ BLOCKING: Run "npm install" to install dependencies');
  readyToStart = false;
}

if (readyToStart) {
  console.log('✅ READY: Server can be started!');
  console.log('\nNext steps:');
  console.log('1. Run database schema in Supabase Dashboard');
  console.log('2. Ensure storage bucket "research-papers" is set to PUBLIC');
  console.log('3. Start server: node server.js');
  console.log('4. Test upload at: http://localhost:3000/research-paper-editor.html');
} else {
  console.log('\n⚠️  Fix the blocking issues above before starting the server');
}

console.log('\n' + '='.repeat(60) + '\n');
