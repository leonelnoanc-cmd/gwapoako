const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

let timelineEvents = [];

app.get('/api/timeline', (req, res) => {
    console.log('[GET] Returning', timelineEvents.length, 'events');
    res.json({ success: true, events: timelineEvents });
});

app.post('/api/timeline', (req, res) => {
    const { title, date } = req.body;
    console.log('[POST] Received:', { title, date });
    
    if (!title || !date) {
        console.log('[POST] Missing fields');
        return res.status(400).json({ error: 'Title and date required' });
    }
    
    const event = { id: 'e_' + Date.now(), title, date };
    timelineEvents.push(event);
    console.log('[POST] Event saved. Total events:', timelineEvents.length);
    res.json({ success: true, event, totalEvents: timelineEvents.length });
});

app.listen(3000, () => {
    console.log('[SERVER] Timeline API listening on http://localhost:3000');
});
