const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');
const dotenv = require('dotenv');

// Load .env from project root (parent directory)
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const app = express();
const PORT = process.env.PORT || 3000;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;

// Serve static files (HTML/CSS/JS) from the project root so files like
// research-paper-editor.html are served with the correct Content-Type.
app.use(express.static(path.join(__dirname, '..')));

app.use(cors());
app.use(express.json());

// Supabase endpoints (submissions, revisions, timeline, notifications)
try {
  const supabaseEndpoints = require('./supabase-endpoints');
  app.use('/api', supabaseEndpoints);
  console.log('✅ Supabase endpoints mounted at /api');
} catch (err) {
  console.warn('⚠️ supabase-endpoints not found or failed to load:', err.message);
}

// Convenience: serve the editor as the root page for quick access
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'research-paper-editor.html')));

if (!ANTHROPIC_API_KEY) {
  console.warn('Warning: ANTHROPIC_API_KEY is not set. Set it in .env to enable live searches.');
}

app.post('/api/search', async (req, res) => {
  const { query } = req.body || {};
  if (!query) return res.status(400).json({ error: 'Missing query parameter' });

  if (!ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: 'Server not configured with ANTHROPIC_API_KEY' });
  }

  try {
    const prompt = `Search for 3 recent academic research papers or scholarly articles about "${query}". For each paper found, provide: 1. The exact title 2. Author names (in APA format: Last, F. M.) 3. Year of publication 4. Journal/publication name 5. A brief 2-3 sentence summary of the key findings 6. DOI or URL if available. Format your response as a JSON array with exactly 3 research papers.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4000,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const text = await response.text();
      console.error('Anthropic API error:', response.status, text);
      return res.status(502).json({ error: `Anthropic API error: ${response.status}` });
    }

    const data = await response.json();

    // Extract text content blocks if present
    let responseText = '';
    if (Array.isArray(data.content)) {
      for (const block of data.content) if (block.type === 'text') responseText += block.text;
    } else if (typeof data.response === 'string') {
      responseText = data.response;
    } else {
      responseText = JSON.stringify(data);
    }

    // Try to parse JSON from the model response
    let papers = [];
    try {
      const cleaned = responseText.replace(/```json\n?|\n?```/g, '').trim();
      papers = JSON.parse(cleaned);
    } catch (err) {
      console.error('Failed to parse model response:', err);
      // Return raw response so frontend can decide what to do
      return res.status(200).json({ raw: responseText });
    }

    return res.status(200).json({ papers });
  } catch (err) {
    console.error('Proxy error:', err);
    return res.status(500).json({ error: err.message || 'Unknown server error' });
  }
});

// In-memory store for share sessions (with 24-hour expiry)
const shareSessions = {};
const SESSION_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

// API endpoint to create a share session
app.post('/api/share/create', (req, res) => {
    try {
        const { section, groups } = req.body;
        
        if (!section || !groups) {
            return res.status(400).json({ error: 'Section and groups are required' });
        }

        // Create session ID
        const sessionId = 'share_' + Date.now();
        
        // Store session data with expiry time
        shareSessions[sessionId] = {
            section: section,
            groups: groups,
            createdAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + SESSION_EXPIRY_MS).toISOString()
        };

        console.log(`✅ Share session created: ${sessionId}`);
        res.json({ success: true, sessionId });
    } catch (error) {
        console.error('Share creation error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// API endpoint to retrieve share session data
app.get('/api/share/:sessionId', (req, res) => {
    try {
        const { sessionId } = req.params;
        const session = shareSessions[sessionId];

        if (!session) {
            return res.status(404).json({ error: 'Share session not found or expired' });
        }

        // Check if session has expired
        if (new Date(session.expiresAt) < new Date()) {
            delete shareSessions[sessionId];
            return res.status(404).json({ error: 'Share session has expired' });
        }

        res.json({ success: true, data: { section: session.section, groups: session.groups } });
    } catch (error) {
        console.error('Share retrieval error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// In-memory store for timeline (shared across all users/devices)
let timelineEvents = [];

// API endpoint to get all timeline events
app.get('/api/timeline', (req, res) => {
    try {
        res.json({ success: true, events: timelineEvents });
    } catch (error) {
        console.error('Timeline retrieval error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// API endpoint to add a timeline event
app.post('/api/timeline', (req, res) => {
    try {
        const { title, date } = req.body;
        
        if (!title || !date) {
            return res.status(400).json({ error: 'Title and date are required' });
        }

        const newEvent = {
            id: 'event_' + Date.now(),
            title,
            date,
            createdAt: new Date().toISOString()
        };
        
        timelineEvents.push(newEvent);
        console.log('[Timeline] Event added:', newEvent);
        
        res.json({ success: true, event: newEvent, totalEvents: timelineEvents.length });
    } catch (error) {
        console.error('Timeline creation error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// API endpoint to delete a timeline event
app.delete('/api/timeline/:eventId', (req, res) => {
    try {
        const { eventId } = req.params;
        const index = timelineEvents.findIndex(e => e.id === eventId);
        
        if (index === -1) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        const deleted = timelineEvents.splice(index, 1)[0];
        console.log('[Timeline] Event deleted:', deleted);
        
        res.json({ success: true, event: deleted, totalEvents: timelineEvents.length });
    } catch (error) {
        console.error('Timeline deletion error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Cleanup expired sessions every hour
setInterval(() => {
    const now = new Date();
    let cleaned = 0;
    for (const sessionId in shareSessions) {
        if (new Date(shareSessions[sessionId].expiresAt) < now) {
            delete shareSessions[sessionId];
            cleaned++;
        }
    }
    if (cleaned > 0) {
        console.log(`🧹 Cleaned up ${cleaned} expired share sessions`);
    }
}, 60 * 60 * 1000);

app.listen(PORT, () => {
  console.log(`Research proxy listening on port ${PORT}`);
});