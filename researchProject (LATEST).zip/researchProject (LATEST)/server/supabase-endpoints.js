/**
 * Supabase API Endpoints
 * Add these routes to your Express server
 */

const express = require('express');
const multer = require('multer');
const {
  uploadPaperFile,
  createSubmission,
  getStudentSubmissions,
  getPendingSubmissions,
  updateSubmissionStatus,
  getSubmissionById,
  requestRevision,
  getSubmissionRevisions,
  createTimelineEvent,
  getTimelineEvents,
  createNotification,
  getUnreadNotifications,
  markNotificationRead
} = require('./supabase-client');

const router = express.Router();

// Configure multer for file uploads (memory storage)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  }
});

// ============================================
// SUBMISSION ENDPOINTS
// ============================================

/**
 * POST /api/submissions/upload
 * Upload a paper file
 * Body: { student_id, student_name, paper_title, chapter, part }
 * File: PDF
 */
router.post('/submissions/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { student_id, student_name, paper_title, chapter, part } = req.body;

    if (!student_id || !paper_title || !chapter || !part) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Upload to Supabase storage
    const { publicUrl } = await uploadPaperFile(
      student_id,
      req.file.buffer,
      req.file.originalname
    );

    // Create submission record
    const submission = await createSubmission({
      student_id,
      student_name,
      paper_title,
      chapter: parseInt(chapter),
      part,
      file_url: publicUrl,
      file_size: req.file.size
    });

    // Notify adviser
    await createNotification(
      'adviser-id', // TODO: Get actual adviser ID
      'submission',
      `New submission: ${paper_title} by ${student_name}`,
      submission.id
    );

    res.json({
      success: true,
      message: 'File uploaded successfully',
      submission
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/submissions/:studentId
 * Get all submissions for a student
 */
router.get('/submissions/:studentId', async (req, res) => {
  try {
    const submissions = await getStudentSubmissions(req.params.studentId);
    res.json({ success: true, data: submissions });
  } catch (error) {
    console.error('Get submissions error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/submissions/pending
 * Get all pending submissions (adviser dashboard)
 */
router.get('/submissions-pending/all', async (req, res) => {
  try {
    const submissions = await getPendingSubmissions();
    res.json({ success: true, data: submissions });
  } catch (error) {
    console.error('Get pending error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/submissions/:submissionId/view
 * Get a single submission
 */
router.get('/submissions/:submissionId/view', async (req, res) => {
  try {
    const submission = await getSubmissionById(req.params.submissionId);
    res.json({ success: true, data: submission });
  } catch (error) {
    console.error('Get submission error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * PATCH /api/submissions/:submissionId/status
 * Update submission status
 * Body: { status: 'approved|rejected|revised' }
 */
router.patch('/submissions/:submissionId/status', async (req, res) => {
  try {
    const { status } = req.body;

    if (!['approved', 'rejected', 'revised', 'in-review'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const submission = await updateSubmissionStatus(
      req.params.submissionId,
      status
    );

    res.json({ success: true, data: submission });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// REVISION ENDPOINTS
// ============================================

/**
 * POST /api/revisions/:submissionId/request
 * Request a revision
 * Body: { feedback: "Please fix..." }
 */
router.post('/revisions/:submissionId/request', async (req, res) => {
  try {
    const { feedback } = req.body;

    if (!feedback) {
      return res.status(400).json({ error: 'Feedback is required' });
    }

    const revision = await requestRevision(
      req.params.submissionId,
      feedback
    );

    res.json({ success: true, data: revision });
  } catch (error) {
    console.error('Request revision error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/revisions/:submissionId
 * Get all revisions for a submission
 */
router.get('/revisions/:submissionId', async (req, res) => {
  try {
    const revisions = await getSubmissionRevisions(req.params.submissionId);
    res.json({ success: true, data: revisions });
  } catch (error) {
    console.error('Get revisions error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// TIMELINE ENDPOINTS
// ============================================

/**
 * POST /api/timeline
 * Create a timeline event
 * Body: { adviser_id, title, due_date, description }
 */
router.post('/timeline', async (req, res) => {
  try {
    const { adviser_id, title, due_date, description } = req.body;

    if (!adviser_id || !title || !due_date) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const event = await createTimelineEvent(adviser_id, title, due_date, description);
    res.json({ success: true, data: event });
  } catch (error) {
    console.error('Create timeline error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/timeline/:adviserId
 * Get timeline events for adviser
 */
router.get('/timeline/:adviserId', async (req, res) => {
  try {
    const events = await getTimelineEvents(req.params.adviserId);
    res.json({ success: true, data: events });
  } catch (error) {
    console.error('Get timeline error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// NOTIFICATION ENDPOINTS
// ============================================

/**
 * GET /api/notifications/:userId
 * Get unread notifications
 */
router.get('/notifications/:userId', async (req, res) => {
  try {
    const notifications = await getUnreadNotifications(req.params.userId);
    res.json({ success: true, data: notifications });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * PATCH /api/notifications/:notificationId/read
 * Mark notification as read
 */
router.patch('/notifications/:notificationId/read', async (req, res) => {
  try {
    const notification = await markNotificationRead(req.params.notificationId);
    res.json({ success: true, data: notification });
  } catch (error) {
    console.error('Mark read error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// ERROR HANDLING
// ============================================

router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'File too large (max 50MB)' });
    }
  }
  console.error('Endpoint error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

module.exports = router;
