#!/usr/bin/env node

/**
 * Supabase Server Startup with Health Checks
 * 
 * This script:
 * 1. Verifies all dependencies are installed
 * 2. Checks environment configuration
 * 3. Tests Supabase connection
 * 4. Starts the server with diagnostic output
 */

const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

console.log('\n🚀 STARTING SUPABASE SERVER\n');
console.log('=' .repeat(60));

// 1. Check environment
console.log('\n1. Checking environment...');
const envPath = path.join(__dirname, '..', '.env');

if (!fs.existsSync(envPath)) {
  console.error('❌ ERROR: .env file not found!');
  console.error('Create .env with your Supabase credentials.');
  console.error('See .env.example for template.');
  process.exit(1);
}

require('dotenv').config({ path: envPath });

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
  console.error('❌ ERROR: Missing Supabase credentials in .env');
  console.error('Required: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

console.log('✅ Environment configured');
console.log(`   📍 Supabase URL: ${process.env.SUPABASE_URL}`);

// 2. Check dependencies
console.log('\n2. Checking dependencies...');
try {
  require('@supabase/supabase-js');
  require('express');
  require('multer');
  console.log('✅ All dependencies installed');
} catch (err) {
  console.error('❌ ERROR: Missing dependencies');
  console.error(`   ${err.message}`);
  console.error('\nRun: npm install');
  process.exit(1);
}

// 3. Test Supabase connection
console.log('\n3. Testing Supabase connection...');
try {
  const { createClient } = require('@supabase/supabase-js');
  const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );
  
  supabase.from('submissions').select('count', { count: 'exact', head: true })
    .then(response => {
      if (response.error) {
        if (response.error.code === '42P01') {
          console.warn('⚠️  WARNING: Database tables not created yet');
          console.warn('   Run SQL schema in Supabase Dashboard first');
        } else {
          console.warn(`⚠️  Supabase warning: ${response.error.message}`);
        }
      } else {
        console.log('✅ Supabase database connection successful');
      }
    })
    .catch(err => {
      console.warn(`⚠️  Connection check: ${err.message}`);
    });
} catch (err) {
  console.error(`❌ ERROR: ${err.message}`);
  process.exit(1);
}

// 4. Check port availability
console.log('\n4. Checking port availability...');
const PORT = process.env.PORT || 3000;
const net = require('net');
const server = net.createServer();

server.once('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`❌ ERROR: Port ${PORT} is already in use`);
    console.error(`   Kill existing process: taskkill /IM node.exe /F`);
    process.exit(1);
  }
});

server.once('listening', () => {
  server.close();
  
  // 5. Start the actual server
  console.log(`✅ Port ${PORT} is available\n`);
  console.log('=' .repeat(60));
  console.log('\n🎉 STARTING SERVER...\n');
  
  // Clear console and start
  console.clear();
  
  const serverProcess = spawn('node', [path.join(__dirname, 'server.js')], {
    stdio: 'inherit',
    cwd: __dirname
  });
  
  serverProcess.on('error', (err) => {
    console.error('Server error:', err);
    process.exit(1);
  });
  
  serverProcess.on('exit', (code) => {
    console.log(`\n\nServer exited with code ${code}`);
    process.exit(code);
  });
});

server.listen(PORT, '127.0.0.1');
