/**
 * Supabase Client Configuration
 * Handles all database and storage operations
 */

const { createClient } = require('@supabase/supabase-js');

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('ERROR: Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// ============================================
// SUBMISSION OPERATIONS
// ============================================

/**
 * Upload a paper file to storage
 * @param {string} userId - Student ID
 * @param {Buffer} fileBuffer - File contents
 * @param {string} fileName - Original filename
 * @returns {Promise<{path: string, publicUrl: string}>}
 */
async function uploadPaperFile(userId, fileBuffer, fileName) {
  try {
    const timestamp = Date.now();
    const filePath = `${userId}/${timestamp}-${fileName}`;

    const { data, error } = await supabase.storage
      .from('research-papers')
      .upload(filePath, fileBuffer, {
        cacheControl: '3600',
        upsert: false,
        contentType: 'application/pdf'
      });

    if (error) throw error;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('research-papers')
      .getPublicUrl(filePath);

    return { path: filePath, publicUrl };
  } catch (error) {
    console.error('Upload error:', error);
    throw new Error(`Failed to upload file: ${error.message}`);
  }
}

/**
 * Create a new submission record
 * @param {Object} submissionData - Submission details
 */
async function createSubmission(submissionData) {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .insert([{
        student_id: submissionData.student_id,
        student_name: submissionData.student_name,
        paper_title: submissionData.paper_title,
        chapter: submissionData.chapter,
        part: submissionData.part,
        file_url: submissionData.file_url,
        file_size: submissionData.file_size,
        status: 'pending',
        submitted_at: new Date().toISOString()
      }])
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Create submission error:', error);
    throw error;
  }
}

/**
 * Get all submissions for a student
 * @param {string} studentId - Student UUID
 */
async function getStudentSubmissions(studentId) {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .select('*')
      .eq('student_id', studentId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get submissions error:', error);
    throw error;
  }
}

/**
 * Get pending submissions (for adviser dashboard)
 */
async function getPendingSubmissions() {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .select('*')
      .eq('status', 'pending')
      .order('submitted_at', { ascending: true });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get pending submissions error:', error);
    throw error;
  }
}

/**
 * Update submission status
 * @param {number} submissionId - Submission ID
 * @param {string} status - New status (pending, in-review, approved, rejected, revised)
 * @param {Object} options - Additional options
 */
async function updateSubmissionStatus(submissionId, status, options = {}) {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', submissionId)
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Update submission error:', error);
    throw error;
  }
}

/**
 * Get submission by ID
 */
async function getSubmissionById(submissionId) {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .select('*')
      .eq('id', submissionId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get submission error:', error);
    throw error;
  }
}

// ============================================
// REVISION OPERATIONS
// ============================================

/**
 * Request a revision
 */
async function requestRevision(submissionId, feedback) {
  try {
    const { data, error } = await supabase
      .from('revisions')
      .insert([{
        submission_id: submissionId,
        adviser_feedback: feedback,
        requested_at: new Date().toISOString()
      }])
      .select();

    if (error) throw error;

    // Update submission status to revision_requested
    await updateSubmissionStatus(submissionId, 'revision_requested');

    return data[0];
  } catch (error) {
    console.error('Request revision error:', error);
    throw error;
  }
}

/**
 * Get revisions for a submission
 */
async function getSubmissionRevisions(submissionId) {
  try {
    const { data, error } = await supabase
      .from('revisions')
      .select('*')
      .eq('submission_id', submissionId)
      .order('revision_number', { ascending: false });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get revisions error:', error);
    throw error;
  }
}

// ============================================
// TIMELINE OPERATIONS
// ============================================

/**
 * Create a timeline event
 */
async function createTimelineEvent(adviserId, title, dueDate, description) {
  try {
    const { data, error } = await supabase
      .from('timelines')
      .insert([{
        adviser_id: adviserId,
        title,
        due_date: dueDate,
        description
      }])
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Create timeline event error:', error);
    throw error;
  }
}

/**
 * Get timeline events for adviser
 */
async function getTimelineEvents(adviserId) {
  try {
    const { data, error } = await supabase
      .from('timelines')
      .select('*')
      .eq('adviser_id', adviserId)
      .order('due_date', { ascending: true });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get timeline events error:', error);
    throw error;
  }
}

// ============================================
// NOTIFICATION OPERATIONS
// ============================================

/**
 * Create a notification
 */
async function createNotification(recipientId, type, message, relatedSubmissionId = null) {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .insert([{
        recipient_id: recipientId,
        notification_type: type,
        message,
        related_submission_id: relatedSubmissionId
      }])
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Create notification error:', error);
    throw error;
  }
}

/**
 * Get unread notifications
 */
async function getUnreadNotifications(userId) {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_id', userId)
      .eq('is_read', false)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get notifications error:', error);
    throw error;
  }
}

/**
 * Mark notification as read
 */
async function markNotificationRead(notificationId) {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId)
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Mark notification error:', error);
    throw error;
  }
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  supabase,
  // File operations
  uploadPaperFile,
  // Submission operations
  createSubmission,
  getStudentSubmissions,
  getPendingSubmissions,
  updateSubmissionStatus,
  getSubmissionById,
  // Revision operations
  requestRevision,
  getSubmissionRevisions,
  // Timeline operations
  createTimelineEvent,
  getTimelineEvents,
  // Notification operations
  createNotification,
  getUnreadNotifications,
  markNotificationRead
};
