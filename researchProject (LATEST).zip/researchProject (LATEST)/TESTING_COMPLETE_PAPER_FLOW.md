# Complete Paper Flow Testing Guide

## Overview
This guide helps you verify that the entire paper submission and review workflow is connected properly, from the student writing the paper to the adviser reviewing it.

---

## 📋 Test Scenario: Complete Paper Submission Flow

### **Step 1: Student Writes and Submits Paper**

#### Setup:
- Open **research-paper-editor.html** (as STUDENT)
- Keep browser console open (**F12 → Console tab**)

#### Action:
1. Write substantial content in the paper editor (at least 100 characters)
2. Click the **"Submit Paper"** button

#### What to Check:
- ✅ **Console Log Check**: Look for:
  ```
  [research-paper-editor] Saving paper content, length: XXX
  [research-paper-editor] Content preview: ...
  [research-paper-editor] Verification - saved content length: XXX
  [research-paper-editor] ✅ Content successfully saved to tempPaperContent
  ```
  
- ✅ **Alert**: Should say "Paper saved! Now select which chapter this content belongs to."

- ✅ **Browser Navigation**: Should redirect to **chapters.html**

- ✅ **localStorage Verification**: Open browser DevTools → **Application → Local Storage**
  - Look for key: `tempPaperContent`
  - Value should contain your content (Click on it to view)
  - **Length indicator**: Right side shows size

---

### **Step 2: Student Selects Chapter**

#### Current Page: **chapters.html**

#### Action:
1. Select a chapter (e.g., "Literature Review")
2. Click the **chapter name** or **Continue** button

#### What to Check:
- ✅ **Console**: No errors about "tempPaperContent"
- ✅ **localStorage**: `tempPaperContent` should STILL exist (not cleared)
- ✅ **Navigation**: Should redirect to **submission.html**

---

### **Step 3: Student Selects Specific Parts and Submits**

#### Current Page: **submission.html**

#### Action:
1. You'll see selected chapter with checkboxes for parts (e.g., "Background", "Methodology")
2. Select at least ONE part checkbox
3. Click the **"SEND"** button

#### What to Check:

**🔍 CRITICAL Console Logs** (in this order):
```
[submission.html] paperContent from storage: ... (should show content start, NOT "EMPTY")

[submission.html] Submission items: [
  { chapter: "...", part: "...", contentLength: XXX }
]
(contentLength should match your content length from Step 1)

[submission.html] ✅ Saved to local submissions array

[submission.html] ✅ Saved to adviserDraftSubmissions

[submission.html] Just saved submission count: 1 or more

[submission.html] First item content length: XXX (SHOULD BE SAME AS ABOVE)
```

**Alert Check**:
- Should say "✅ Submission sent successfully!"

**localStorage Verification**:
- Open **Application → Local Storage**
- Look for `adviserDraftSubmissions` key
  - Should contain array with your submission
  - **Check the content**: Expand the JSON, find `items[0].content` - should have your text

---

### **Step 4: Switch to Adviser Browser**

#### New Browser/Incognito Window:
- Open **revise-paper-student.html** (as ADVISER)
- Look at URL - should be something like: `revise-paper-student.html?submitter=StudentUsername&chapter=...`
- Keep console open (**F12 → Console**)

#### What to Check - CRITICAL Logs:

**When page loads, console should show:**

```
[loadSharedRevisionContent] ========== STARTING ==========

[loadSharedRevisionContent] Fetching from server...

[loadSharedRevisionContent] Server response status: 200 or similar

[loadSharedRevisionContent] Response has X submissions
```

**If submission not on server yet** (expected if just submitted locally):
```
[loadSharedRevisionContent] ❌ NOT found on server

[loadSharedRevisionContent] Fallback: Checking local localStorage submissions...

[loadSharedRevisionContent] adviserDraftSubmissions count: 1 (or higher)

[loadSharedRevisionContent] Final submissions count: 1 (or higher)

  [0] From: StudentUsername | Items: 1 | Content lengths: [XXX]

[loadSharedRevisionContent] ✅ FOUND submission from Student
```

**Then content loading:**
```
[loadContentFromSubmission] ========== STARTING ==========

[loadContentFromSubmission] Item 0: Chapter - Part | Content length: XXX

[loadContentFromSubmission] Total content to load: XXX characters

[loadContentFromSubmission] ✅ Content successfully set to Quill
```

---

### **Step 5: Verify Content is Visible**

#### Current Page: **revise-paper-student.html**

#### Visual Check:
- ✅ **Content appears** in the editor area
- ✅ **NOT empty** - should show your actual text
- ✅ **Formatted properly** - bold, italics, etc. should display

#### If Content is NOT Visible:
Look for errors:
```
[loadContentFromSubmission] ⚠️ Item 0 has NO content!
⚠️ Content is empty - Please resubmit the paper
```

If you see this, check:
1. Go back to **submission.html** console
2. Look for `First item content length: 0`
3. If 0, the content was not saved to adviserDraftSubmissions
4. Check `tempPaperContent` in localStorage - does it have content?

---

## 🔧 Troubleshooting Guide

### Problem: "No content found for [Part Name]"

**Cause**: Content wasn't linked to that specific part in submission.html

**Fix**:
1. Go back to student browser
2. Use **Back button** to return to chapters.html
3. Start over with Step 2

### Problem: Content appears empty in adviser view

**Cause**: One of these:
1. tempPaperContent was cleared before being saved
2. adviserDraftSubmissions doesn't have the content
3. Content got lost during submission

**Fix - Check localStorage in Student Browser**:
1. Open **F12 → Application → Local Storage**
2. Look for `tempPaperContent` - **does it exist?**
   - **NO**: Go back to Step 1, write content again
   - **YES**: Check size - should be large
3. Look for `adviserDraftSubmissions` - **does it exist?**
   - **NO**: Content didn't get saved, check Step 3 console
   - **YES**: Expand it, find `items[0].content` - **is it empty?**
     - **Empty**: Return to Step 3, check console for `First item content length: 0`

### Problem: Adviser's adviser-group-dashboard.html shows "pending" instead of "submitted"

**Cause**: getPartStatus() couldn't find the submission

**Fix**:
1. Go to student's group-dashboard.html (adviser view)
2. Open console, look for getPartStatus() calls
3. Check if `getSubmitterForPart()` found a submitter
4. Verify adviserDraftSubmissions has the data

---

## 📊 Key localStorage Keys to Monitor

| Key | Location | Purpose | Should Contain |
|-----|----------|---------|---|
| `tempPaperContent` | Both browsers | Temporary content from editor | HTML string of paper |
| `tempPaperReferences` | Both browsers | References from editor | JSON array of references |
| `submissions` | Both browsers | Local submissions array | Array of submission objects |
| `adviserDraftSubmissions` | Both browsers | **PRIMARY** adviser source | Array of submissions |
| `revisionNotifications_[user]` | Both browsers | Which parts need revision | Array of parts |

---

## ✅ Success Criteria

**Complete workflow is working when:**

- [x] Student writes content in research-paper-editor.html
- [x] Content saves to `tempPaperContent` (verified in console)
- [x] Content remains through chapters.html
- [x] Content links to specific parts in submission.html
- [x] Submission saves to `adviserDraftSubmissions` (verified in console)
- [x] Content appears in adviser's revise-paper-student.html
- [x] Adviser can highlight text and add feedback
- [x] Student can see revision notifications
- [x] Student can access revision editor and make changes

---

## 🎯 Next Steps After Verification

If complete flow works:
1. Test revision workflow: Adviser marks parts for revision
2. Test student sees notification in revision-parts.html
3. Test student can edit and resubmit with revision-paper.html
4. Test adviser can see revised version

If any step fails:
1. **Document the step number** where it fails
2. **Copy the console error** (if any)
3. **Check the Problem section** above for guidance
4. **Verify localStorage** contents at that step

---

## 💡 Pro Tips

- **Keep browser console open** during entire test
- **Don't close either browser** mid-test - separate localStorage instances
- **Take screenshots** of console logs if troubleshooting
- **Check network tab** if trying to diagnose server issues
- **Look for "[xxx.html]" prefixes** in logs to know which file is logging

