# ⚡ Quick Connection Verification Checklist

## 🚀 30-Second Test

**Setup:**
- Have TWO browser windows ready (Student + Adviser)
- Keep F12 Console open in BOTH

**Test:**

### Step 1: Student Editor (30 seconds)
- [ ] Open `research-paper-editor.html` (Student browser)
- [ ] Write: "This is test content to verify the flow is working properly."
- [ ] Click "Submit Paper"
- [ ] Check console for: `[research-paper-editor] ✅ Content successfully saved`
- [ ] **PASS if:** Console shows content length > 50

### Step 2: Chapter Selection (10 seconds)
- [ ] Click any chapter
- [ ] Check console: NO errors about tempPaperContent
- [ ] **PASS if:** No red errors in console

### Step 3: Parts Selection (20 seconds)
- [ ] In `submission.html`, check ONE part (e.g., "Background")
- [ ] Click "SEND"
- [ ] Check console for: `[submission.html] First item content length: XXX`
- [ ] **PASS if:** Number > 50 (matches your text length)

### Step 4: Adviser Review (30 seconds)
- [ ] In Adviser browser, open `revise-paper-student.html`
- [ ] Check console for: `[loadContentFromSubmission] ✅ Content successfully set`
- [ ] Look at paper area: Does your text appear?
- [ ] **PASS if:** Text is visible and not empty

---

## 📋 Detailed Checkpoint List

### Research-Paper-Editor.html
**Location**: Lines 1538-1570

- [ ] Console shows `[research-paper-editor] Saving paper content, length: XXX`
- [ ] Console shows content preview (first 100 chars)
- [ ] Console shows `[research-paper-editor] Verification - saved content length: XXX`
- [ ] `tempPaperContent` exists in localStorage (F12 → Application → Local Storage)
- [ ] `tempPaperContent` contains your written text
- [ ] Alert says "Paper saved! Now select which chapter..."

**If any ❌:** Go back to editor, write more content, try again

---

### Chapters.html
**No modifications needed** - just pass-through

- [ ] `tempPaperContent` still in localStorage
- [ ] No console errors
- [ ] Click chapter to proceed

**If ❌:** tempPaperContent missing, restart at research-paper-editor.html

---

### Submission.html
**Location**: Lines 64-155

**BEFORE clicking SEND:**
- [ ] Check console shows: `[submission.html] paperContent from storage: ...` 
  - Should NOT say "EMPTY"
  - Should show first part of your content

**AFTER clicking SEND:**
- [ ] Console shows: `[submission.html] Submission items: [{ chapter: "...", contentLength: XXX }]`
  - **contentLength must match your original content length**
- [ ] Console shows: `[submission.html] ✅ Saved to adviserDraftSubmissions`
- [ ] Console shows: `[submission.html] First item content length: XXX` 
  - **This number is CRITICAL - must match Step 1**
- [ ] Alert says "Submission sent ✅"
- [ ] Redirected to `draft.html`

**localStorage verification:**
- [ ] `adviserDraftSubmissions` key exists
- [ ] Expand JSON: `adviserDraftSubmissions[0].items[0].content`
- [ ] Content field contains your text (not empty)

**If ❌:** 
- If "Paper content was lost" error: tempPaperContent wasn't saved properly
- If "First item content length: 0": Content didn't link to part
- Check console for error messages starting with "CRITICAL"

---

### Draft.html
**Location**: Lines 420-450

- [ ] Opens automatically after submission
- [ ] Console shows: `[draft.html] adviserDraftSubmissions count: X`
- [ ] Console shows: `[draft.html] Item: 1_Background content length: XXX`
- [ ] Your paper content is visible (or partially visible)

**If ❌:** 
- If count is 0: adviserDraftSubmissions not populated
- If content length is 0: Content lost in submission

---

### Revise-Paper-Student.html (Adviser Browser)
**Location**: Lines 1041-1280

**Console checks:**
- [ ] Shows: `[loadSharedRevisionContent] ========== STARTING ==========`
- [ ] Shows: `[loadSharedRevisionContent] adviserDraftSubmissions count: X` (should be > 0)
- [ ] Shows: `[0] From: StudentName | Items: 1 | Content lengths: [XXX]`
- [ ] Shows: `[loadContentFromSubmission] Item 0: ... | Content length: XXX`
- [ ] Shows: `[loadContentFromSubmission] ✅ Content successfully set to Quill`

**Visual check:**
- [ ] Paper content is visible in editor
- [ ] NOT blank/empty
- [ ] Can see your test text
- [ ] NO warning: "⚠️ Content is empty - Please resubmit"

**If ❌:**
- If console shows `adviserDraftSubmissions count: 0`: Data didn't save in submission.html
- If content length is 0: Content lost during submission
- If visual is empty: Check for red error messages in console

---

## 🎯 Success Criteria

**ALL of these must be TRUE:**

1. ✅ Student can write and submit paper in research-paper-editor.html
2. ✅ Console shows content length preserved through all steps
3. ✅ Content saves to `adviserDraftSubmissions` in localStorage
4. ✅ Adviser can view paper in revise-paper-student.html
5. ✅ Paper displays with actual text (not empty)
6. ✅ No console errors with "[xxx.html] CRITICAL" prefix
7. ✅ No warnings about empty content

---

## 🔴 Red Flags (STOP & DEBUG if you see these)

**In any console:**
- `[xxx.html] CRITICAL: paperContent is empty!`
- `[submission.html] First item content length: 0`
- `⚠️ Item has NO content!`
- `Error: Paper content was lost`

**In localStorage:**
- `adviserDraftSubmissions` doesn't exist (count = 0 in console)
- `adviserDraftSubmissions[0].items[0].content` is empty string

**Visual:**
- Adviser paper area is blank when it should show text
- "No content found for [Part]" message appears

---

## 📱 Checkpoint Summary Table

| Checkpoint | Should See | If ❌ Do This |
|---|---|---|
| After submitPaper() | Content length > 50 in console | Check tempPaperContent in localStorage |
| In localStorage | tempPaperContent key with text | Restart at research-paper-editor.html |
| Before SEND | "paperContent from storage: ..." | Check console for CRITICAL error |
| After SEND | "First item content length: XXX" (>50) | Check adviserDraftSubmissions in localStorage |
| In adviserDraftSubmissions | items[0].content has text | Return to submission.html and resubmit |
| In revise-paper-student.html | "Content successfully set to Quill" | Check console for errors |
| Visual in adviser | Paper text appears | Check for empty content warning message |

---

## 💡 Pro Debugging Tips

1. **Keep two console windows visible**:
   - Student browser: Watch data go INTO system
   - Adviser browser: Watch data come OUT of system

2. **Copy-paste console checks**:
   ```javascript
   // In student browser after submission
   JSON.parse(localStorage.getItem('adviserDraftSubmissions'))[0].items[0].content.substring(0, 100)
   
   // Should show your test content, NOT empty
   ```

3. **Check localStorage size**:
   - Right-click localStorage key → see file size
   - ~0 bytes = empty, ~1KB+ = has content

4. **Use Ctrl+Shift+K** in Chrome to clear localStorage if needed to start fresh

5. **Screenshot console logs** if troubleshooting - helps identify exact failure point

---

## ✅ Final Validation

**System is working correctly when:**

```
┌─ Student Editor ──────────────────────┐
│ ✅ Write content                      │
│ ✅ tempPaperContent saved (shows len) │
└───────────────────────────────────────┘
                    │ Submit
                    ↓
┌─ Submission Page ─────────────────────┐
│ ✅ paperContent retrieved             │
│ ✅ Content length preserved           │
│ ✅ Saved to adviserDraftSubmissions   │
│ ✅ First item length matches original │
└───────────────────────────────────────┘
                    │ Send
                    ↓
┌─ Adviser Review Page ─────────────────┐
│ ✅ Loaded from adviserDraftSubmissions│
│ ✅ Content length not zero            │
│ ✅ Content displayed in editor        │
│ ✅ Can highlight and add feedback     │
└───────────────────────────────────────┘
```

---

## 🚦 If Content Still Missing

**Step-by-step diagnosis:**

1. **Open research-paper-editor.html**
   - Write test content
   - Submit
   - Check console: Note the content length shown
   - Remember this number ← **This is your target length**

2. **Go to submission.html**
   - Check console: `First item content length:` should show same number
   - If different, content got lost here
   - If 0, content wasn't saved

3. **Check localStorage**
   - In student browser: Application → Local Storage
   - Find key: `adviserDraftSubmissions`
   - Expand JSON, find: `[0].items[0].content`
   - **If empty**: Problem in submission.html
   - **If full**: Problem in adviser browser loading

4. **Check adviser browser**
   - Open revise-paper-student.html
   - Press F12 → Console
   - Look for: `[loadSharedRevisionContent] adviserDraftSubmissions count:`
   - **If 0**: Student localStorage data not reaching adviser
   - **If > 0**: Data transferred, check loading logs

5. **Check visual display**
   - If adviser shows "No content found": adviserDraftSubmissions found but content empty
   - If adviser shows blank editor: Content is there but display issue

---

## 📞 Information to Collect Before Seeking Help

If system isn't working:

1. **Screenshot console from submission.html** showing all `[submission.html]` logs
2. **Screenshot localStorage** showing `adviserDraftSubmissions` key and content
3. **Screenshot revise-paper-student.html console** showing all `[loadSharedRevisionContent]` logs
4. **Note the content length** from Step 1 vs Step 3 (should match)
5. **Note which browser** student vs adviser (separate windows?)
6. **Check if ngrok server is running** (POST to /api/submissions/draft needs it)

