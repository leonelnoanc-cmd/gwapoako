# Research Paper Submission Flow - Implementation Guide

## Complete System Flow (As Implemented)

This document outlines the **structured submission flow** for research papers, as requested.

---

## 1. Research Paper Creation Phase

### Files Involved:
- `research-paper-editor.html` (for regular students)
- `research-paper-editor-leader.html` (for group leaders)

### What Happens:
1. User writes and edits their research content in the Quill editor
2. User adds references manually
3. User clicks **"Submit Paper"** button

### Data Storage:
When "Submit Paper" is clicked:
```javascript
localStorage.setItem('tempPaperContent', quill.root.innerHTML);
localStorage.setItem('tempPaperReferences', JSON.stringify(references));
```

### Navigation:
- `research-paper-editor.html` → `chapters.html`
- `research-paper-editor-leader.html` → `chapters-leader.html`

---

## 2. Chapter Selection Phase

### Files Involved:
- `chapters.html` (for regular students)
- `chapters-leader.html` (for group leaders)

### What Happens:
1. User sees a list of 5 chapters with their component parts
2. User selects which chapter(s) their content belongs to by checking checkboxes
3. User clicks **"Next"** button

### Chapter List:
- **Chapter 1**: Background, Problem, Frameworks, Significance, Scope, Definitions
- **Chapter 2**: Related Literature, Related Studies
- **Chapter 3**: Research Design, Locale, Instrument, Data Gathering, Analysis
- **Chapter 4**: Key Findings
- **Chapter 5**: Summary, Implications, Conclusions, Recommendations, References, Appendices, CV

### Navigation:
- `chapters.html?chapters=[1,2,3]` → `submission.html?chapters=[1,2,3]`
- `chapters-leader.html?chapters=[1,2,3]` → `submission-leader.html?chapters=[1,2,3]`

---

## 3. Chapter Part Selection Phase

### Files Involved:
- `submission.html` (for regular students)
- `submission-leader.html` (for group leaders)

### What Happens:
1. Based on selected chapters, specific chapter parts are displayed
2. User selects which specific part(s) their content belongs to (e.g., "Background of the Study")
3. User clicks **"Send"** button

### Example:
If user selected "Chapter 1" and "Chapter 2":
```
Chapter 1:
  ☑ Background of the Study
  ☐ Statement of the Problem
  ☐ Conceptual Framework
  ☐ Theoretical Framework
  ☐ Significance of the Study
  ☐ Scope and Delimitation
  ☐ Definition of Terms

Chapter 2:
  ☐ Review of Related Literature
  ☐ Review of Related Studies
```

### Data Submission:
The selected parts are linked with the content:
```javascript
const submission = {
    paperIndex: Number(paperIndex) || null,
    items: [
        { chapter: '1', part: 'Background of the Study', content: '...' },
        { chapter: '1', part: 'Statement of the Problem', content: '...' }
    ],
    submittedAt: new Date().toISOString(),
    references: JSON.stringify(references),
    submittedBy: 'username'
};

localStorage.setItem('submissions', JSON.stringify([...existing, submission]));
```

### Temporary Data Cleanup:
```javascript
localStorage.removeItem('tempPaperContent');
localStorage.removeItem('tempPaperReferences');
```

### Navigation:
- `submission.html` → `draft.html`
- `submission-leader.html` → `draft.html`

---

## 4. Draft Organization & Display Phase

### Files Involved:
- `draft.html`

### What Happens:
1. System retrieves all submissions from `localStorage.submissions`
2. Content is organized by:
   - **Chapter number** (1 → 2 → 3 → 4 → 5)
   - **Chapter part order** (based on predefined structure)
3. Full academic paper is displayed with proper formatting

### Organization Logic:
```javascript
const chapterStructure = {
    '1': ['Background of the Study', 'Statement of the Problem', ...],
    '2': ['Review of Related Literature', 'Review of Related Studies'],
    '3': ['Research Design', 'Locale of the Study', ...],
    '4': ['Presentation of Key Findings'],
    '5': ['Summary', 'Implication of Findings', ...]
};

// Display in order
['1', '2', '3', '4', '5'].forEach(chapterNum => {
    chapterStructure[chapterNum].forEach(partName => {
        // Display submitted content for this part
    });
});
```

### Display Format:
```
[Part Title]
[Submitted Content]

[References Section]
1. Reference 1
2. Reference 2
...
```

---

## 5. Data Flow Diagram

```
┌─────────────────────────────┐
│   Create Content            │
│  (editor-leader.html)       │
└──────────────┬──────────────┘
               │ tempPaperContent
               │ tempPaperReferences
               ↓
┌─────────────────────────────┐
│   Select Chapter            │
│  (chapters-leader.html)     │
└──────────────┬──────────────┘
               │ chapters param
               ↓
┌─────────────────────────────┐
│   Select Chapter Part       │
│ (submission-leader.html)    │
└──────────────┬──────────────┘
               │ chapter + part
               │ + content
               ↓
┌─────────────────────────────┐
│   Save Submission           │
│ (localStorage.submissions)  │
└──────────────┬──────────────┘
               │ submissions array
               ↓
┌─────────────────────────────┐
│   View Organized Draft      │
│      (draft.html)           │
│   [Properly Structured      │
│    Research Paper]          │
└─────────────────────────────┘
```

---

## 6. localStorage Keys Used

| Key | Purpose | Format |
|-----|---------|--------|
| `tempPaperContent` | Temporarily stores editor HTML content | HTML string |
| `tempPaperReferences` | Temporarily stores references | JSON array |
| `submissions` | All submitted content organized by chapter/part | JSON array |
| `loggedInUser` | Current user info | JSON object |
| `userRole` | Current user role (student-leader, etc.) | String |

---

## 7. Expected Submission Format

```json
{
    "submissions": [
        {
            "paperIndex": null,
            "items": [
                {
                    "chapter": "1",
                    "part": "Background of the Study",
                    "content": "<p>HTML content here...</p>"
                },
                {
                    "chapter": "1",
                    "part": "Statement of the Problem",
                    "content": "<p>HTML content here...</p>"
                }
            ],
            "submittedAt": "2026-01-20T10:30:00Z",
            "references": "[\"Reference 1\", \"Reference 2\"]",
            "submittedBy": "john_doe"
        }
    ]
}
```

---

## 8. Key Rules & Constraints

✅ **DO:**
- Save content to `tempPaperContent` before redirecting to chapters
- Organize submissions by chapter number first
- Sort parts within each chapter by predefined order
- Preserve content through all page transitions
- Link user info to each submission

❌ **DON'T:**
- Delete temporary data until successful submission
- Allow chapter/part selection without prior content
- Skip the chapter selection step
- Store content in `paperContent` (use `tempPaperContent` instead)

---

## 9. Current Implementation Status

✅ **Completed:**
- Research paper editor pages (both regular and leader)
- Chapter selection pages with redirect logic
- Chapter part selection pages with submission logic
- Draft organization and display logic
- localStorage data flow

✅ **Updated:**
- `research-paper-editor-leader.html` - Now redirects to `chapters-leader.html`
- `draft.html` - Updated to support both standard and legacy `paperContent` format

---

## 10. Testing the Flow

### Test Case 1: Regular Student
1. Open `research-paper-editor.html`
2. Write some content
3. Click "Submit Paper"
4. Select Chapter 1 and Chapter 2
5. Click "Next"
6. Select parts from chapters
7. Click "Send"
8. Verify content appears in `draft.html` organized by chapter

### Test Case 2: Group Leader
1. Open `research-paper-editor-leader.html`
2. Write some content
3. Click "Submit Paper"
4. Select Chapter 1
5. Click "Next"
6. Select parts from Chapter 1
7. Click "Send"
8. Verify content appears in `draft.html`

---

**Last Updated:** January 20, 2026  
**Status:** ✅ IMPLEMENTED AND READY FOR USE
