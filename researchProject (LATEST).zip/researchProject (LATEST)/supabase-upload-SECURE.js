/**
 * Supabase Secure File Upload Module - IMPROVED VERSION
 * Security enhancements:
 * - Input validation
 * - XSS prevention
 * - File type verification
 * - CSRF token support
 * - Secure error handling
 * - Retry logic
 */

class SecurePaperUploader {
  constructor(apiServerUrl) {
    this.apiServerUrl = apiServerUrl || window.API_SERVER_URL || 'http://localhost:3000';
    this.maxFileSize = 50 * 1024 * 1024; // 50MB
    this.maxRetries = 3;
    this.csrfToken = this.getCsrfToken();
  }

  /**
   * Get CSRF token from page or local storage
   */
  getCsrfToken() {
    // Try to get from meta tag
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    if (metaTag) return metaTag.getAttribute('content');
    
    // Try local storage
    return localStorage.getItem('csrfToken') || '';
  }

  /**
   * Sanitize HTML to prevent XSS
   */
  sanitizeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text; // textContent doesn't parse HTML
    return div.innerHTML;
  }

  /**
   * Validate email format
   */
  validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  /**
   * Validate PDF file
   */
  validatePdfFile(file) {
    // Check file type
    if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
      throw new Error('❌ Invalid file type. Only PDF files are allowed.');
    }

    // Check file size
    if (file.size === 0) {
      throw new Error('❌ File is empty.');
    }

    if (file.size > this.maxFileSize) {
      throw new Error(`❌ File is too large. Maximum size is 50MB.`);
    }

    // Check magic bytes for PDF
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const arr = new Uint8Array(e.target.result).subarray(0, 4);
        let header = '';
        for (let i = 0; i < arr.length; i++) {
          header += arr[i].toString(16);
        }
        // PDF magic bytes: %PDF (25504446)
        if (header.toLowerCase().startsWith('25504446') || header === '255044462d') {
          resolve(true);
        } else {
          reject(new Error('❌ File does not appear to be a valid PDF.'));
        }
      };
      reader.onerror = () => reject(new Error('❌ Error reading file.'));
      reader.readAsArrayBuffer(file.slice(0, 4));
    });
  }

  /**
   * Upload paper with validation
   */
  async uploadPaper(file, metadata, options = {}) {
    try {
      const { showProgress = true, onProgress = null } = options;

      // SECURITY: Validate file
      await this.validatePdfFile(file);

      // SECURITY: Validate metadata
      if (!metadata.student_id || typeof metadata.student_id !== 'string') {
        throw new Error('Invalid student ID');
      }

      if (!metadata.paper_title || typeof metadata.paper_title !== 'string') {
        throw new Error('Invalid paper title');
      }

      if (!metadata.chapter) {
        throw new Error('Invalid chapter');
      }

      // SECURITY: Validate chapter is numeric
      const chapter = parseInt(metadata.chapter);
      if (isNaN(chapter) || chapter < 1 || chapter > 100) {
        throw new Error('Chapter must be between 1 and 100');
      }

      if (!metadata.part || typeof metadata.part !== 'string') {
        throw new Error('Invalid part');
      }

      // SECURITY: Sanitize inputs
      metadata.student_id = metadata.student_id.trim().slice(0, 50);
      metadata.student_name = (metadata.student_name || 'Unknown').trim().slice(0, 100);
      metadata.paper_title = metadata.paper_title.trim().slice(0, 255);
      metadata.part = metadata.part.trim().slice(0, 500);

      if (showProgress) {
        console.log('📤 Uploading paper:', file.name);
      }

      // Create FormData
      const formData = new FormData();
      formData.append('file', file);
      formData.append('student_id', metadata.student_id);
      formData.append('student_name', metadata.student_name);
      formData.append('paper_title', metadata.paper_title);
      formData.append('chapter', chapter.toString());
      formData.append('part', metadata.part);

      // SECURITY: Add auth token and CSRF token
      const headers = {
        'X-CSRF-Token': this.csrfToken
      };

      const authToken = localStorage.getItem('authToken');
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }

      // Upload with retry logic
      let lastError;
      for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
        try {
          if (showProgress && attempt > 1) {
            console.log(`🔄 Retry attempt ${attempt}/${this.maxRetries}`);
          }

          const response = await fetch(`${this.apiServerUrl}/api/submissions/upload`, {
            method: 'POST',
            body: formData,
            headers: headers
          });

          if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || `Upload failed with status ${response.status}`);
          }

          const result = await response.json();

          if (!result.success) {
            throw new Error(result.error || 'Upload returned error');
          }

          if (showProgress) {
            console.log('✅ Upload successful!');
          }

          return {
            success: true,
            message: 'Paper uploaded successfully',
            submission: result.submission,
            fileUrl: result.submission.file_url
          };
        } catch (error) {
          lastError = error;
          if (attempt < this.maxRetries) {
            // Wait before retry (exponential backoff)
            await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)));
          }
        }
      }

      throw lastError || new Error('Upload failed after retries');
    } catch (error) {
      console.error('❌ Upload error:', error);
      return {
        success: false,
        error: error.message || 'Upload failed. Please try again.'
      };
    }
  }

  /**
   * Get student's submissions
   */
  async getSubmissions(studentId) {
    try {
      if (!studentId || typeof studentId !== 'string') {
        throw new Error('Invalid student ID');
      }

      studentId = studentId.trim().slice(0, 50);

      const response = await fetch(
        `${this.apiServerUrl}/api/submissions/${encodeURIComponent(studentId)}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }

      return await response.json();
    } catch (error) {
      console.error('❌ Get submissions error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get pending submissions (adviser)
   */
  async getPendingSubmissions() {
    try {
      const response = await fetch(
        `${this.apiServerUrl}/api/submissions-pending/all`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch submissions');
      }

      return await response.json();
    } catch (error) {
      console.error('❌ Get pending error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Update submission status
   */
  async updateStatus(submissionId, status) {
    try {
      if (!submissionId) {
        throw new Error('Invalid submission ID');
      }

      const validStatuses = ['approved', 'rejected', 'revised', 'in-review', 'pending'];
      if (!validStatuses.includes(status)) {
        throw new Error('Invalid status');
      }

      const response = await fetch(
        `${this.apiServerUrl}/api/submissions/${encodeURIComponent(submissionId)}/status`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`,
            'X-CSRF-Token': this.csrfToken
          },
          body: JSON.stringify({ status })
        }
      );

      if (!response.ok) {
        throw new Error('Failed to update status');
      }

      return await response.json();
    } catch (error) {
      console.error('❌ Update status error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Request a revision with validation
   */
  async requestRevision(submissionId, feedback) {
    try {
      if (!submissionId) {
        throw new Error('Invalid submission ID');
      }

      if (!feedback || typeof feedback !== 'string') {
        throw new Error('Invalid feedback');
      }

      // SECURITY: Sanitize feedback
      feedback = feedback.trim().slice(0, 5000);

      if (feedback.length < 10) {
        throw new Error('Feedback must be at least 10 characters');
      }

      const response = await fetch(
        `${this.apiServerUrl}/api/revisions/${encodeURIComponent(submissionId)}/request`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`,
            'X-CSRF-Token': this.csrfToken
          },
          body: JSON.stringify({ feedback })
        }
      );

      if (!response.ok) {
        throw new Error('Failed to request revision');
      }

      return await response.json();
    } catch (error) {
      console.error('❌ Request revision error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get revisions for a submission
   */
  async getRevisions(submissionId) {
    try {
      if (!submissionId) {
        throw new Error('Invalid submission ID');
      }

      const response = await fetch(
        `${this.apiServerUrl}/api/revisions/${encodeURIComponent(submissionId)}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch revisions');
      }

      return await response.json();
    } catch (error) {
      console.error('❌ Get revisions error:', error);
      return { success: false, error: error.message };
    }
  }
}

// Make it available globally
window.SecurePaperUploader = SecurePaperUploader;

// Usage Example:
// ============
// 
// HTML:
// <input type="file" id="paperInput" accept=".pdf">
// <button onclick="uploadPaper()">Upload</button>
// <div id="uploadStatus"></div>
//
// JavaScript:
// const uploader = new SecurePaperUploader();
//
// async function uploadPaper() {
//   const file = document.getElementById('paperInput').files[0];
//   const statusDiv = document.getElementById('uploadStatus');
//   
//   try {
//     const result = await uploader.uploadPaper(file, {
//       student_id: 'student-123',
//       student_name: 'John Doe',
//       paper_title: 'Introduction',
//       chapter: 1,
//       part: 'Background of the Study'
//     });
//
//     if (result.success) {
//       statusDiv.innerHTML = '✅ Upload successful!';
//       console.log('File URL:', result.fileUrl);
//     } else {
//       statusDiv.innerHTML = '❌ Error: ' + result.error;
//     }
//   } catch (error) {
//     statusDiv.innerHTML = '❌ Upload failed: ' + error.message;
//   }
// }
