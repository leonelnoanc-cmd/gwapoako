# Supabase Setup - Visual Guide & Troubleshooting

## Step 1: Database Schema Setup

### Where to Find SQL Editor
```
Supabase Dashboard
├─ Left Sidebar
│  └─ SQL Editor ← CLICK HERE
│     └─ New Query ← CLICK HERE
└─ Browser URL: https://app.supabase.com/project/<id>/sql/new
```

### What to Do
1. Click "New Query" button
2. Delete the default "Hello World" query if present
3. Copy **EVERYTHING** from `SUPABASE_SCHEMA_READY_TO_COPY.sql`
4. Paste into the editor
5. Click blue "Run" button (or press Ctrl+Enter)

### Expected Success Messages
```
✅ Query executed successfully

Created index "idx_submissions_student_id"
Created index "idx_submissions_status"
...
Created table "notifications"
```

### How to Verify Tables Were Created
```
Supabase Dashboard
├─ Left Sidebar
│  └─ Table Editor ← CLICK HERE
└─ You should see these 6 tables:
   ├─ submissions (with icon)
   ├─ revisions
   ├─ timelines
   ├─ groups
   ├─ group_members
   └─ notifications
```

### Common Issues

**Problem:** "Error: relation "submissions" already exists"
- **Cause:** Tables were already created from a previous run
- **Solution:** Delete the existing tables first, then run the schema again
  ```sql
  DROP TABLE IF EXISTS notifications CASCADE;
  DROP TABLE IF EXISTS group_members CASCADE;
  DROP TABLE IF EXISTS revisions CASCADE;
  DROP TABLE IF EXISTS submissions CASCADE;
  DROP TABLE IF EXISTS timelines CASCADE;
  DROP TABLE IF EXISTS groups CASCADE;
  ```

**Problem:** "Error: syntax error at or near..."
- **Cause:** Incomplete SQL or copy/paste error
- **Solution:** 
  1. Open `SUPABASE_SCHEMA_READY_TO_COPY.sql`
  2. Verify the entire file is copied (should be ~200 lines)
  3. Delete current query and try again

**Problem:** No tables appear in Table Editor
- **Cause:** Query didn't actually execute or failed silently
- **Solution:** 
  1. Check the "Query Results" panel at bottom
  2. Look for error messages in red
  3. Scroll right to see all output

---

## Step 2: Storage Bucket Setup

### Where to Find Storage
```
Supabase Dashboard
├─ Left Sidebar
│  └─ Storage ← CLICK HERE
│     └─ Create a new bucket ← CLICK HERE
└─ Browser URL: https://app.supabase.com/project/<id>/storage/buckets
```

### Exact Configuration
```
Bucket Name:    research-papers
                (MUST be lowercase, no spaces, exact spelling)

Access Level:   Public
                (This is critical! Papers must be publicly accessible)

File Size:      Leave as default (50MB or higher is fine)
Encryption:     Leave default
Allowed MIME:   Leave blank (allows all file types)
```

### How to Make Bucket Public
```
Supabase Dashboard → Storage
├─ Click bucket name: "research-papers"
├─ Click "Settings" tab
├─ Access Control section
│  └─ Select: "Public"
└─ Click "Save"
```

### Success Verification
```
Storage bucket list shows:
├─ research-papers (with blue "public" badge)
└─ Clicking the bucket shows empty folder
```

### Common Issues

**Problem:** "Can't upload files to bucket"
- **Cause:** Bucket is not set to "Public"
- **Solution:** Go to Storage → research-papers → Settings → Change to Public

**Problem:** "File uploaded but URL is not accessible"
- **Cause:** Bucket is not public OR URL format is wrong
- **Solution:**
  1. Verify bucket is Public (settings)
  2. URL format should be: 
     ```
     https://wgnbejkryaswxvvhmaff.supabase.co/storage/v1/object/public/research-papers/...
     ```

**Problem:** "Error creating bucket - already exists"
- **Cause:** Bucket was created in a previous attempt
- **Solution:**
  1. Go to Storage
  2. Click bucket "research-papers"
  3. Click "Delete bucket" (bottom of page)
  4. Confirm
  5. Create new bucket with same name

---

## Step 3: Upload Testing

### Prerequisites Checklist
Before testing, verify:
- ✅ Server running: `node server/server.js`
- ✅ Database tables created (6 tables visible in Table Editor)
- ✅ Storage bucket exists and is public
- ✅ `.env` file exists in project root
- ✅ `.env` contains all 5 variables (SUPABASE_URL, SUPABASE_ANON_KEY, etc.)

### Test Procedure

**1. Start the Server**
```powershell
cd "c:\Users\ADMIN\researchProject (LATEST)"
node server/server.js
```

Wait for:
```
✅ Supabase endpoints mounted at /api
✅ Server running on http://localhost:3000
```

**2. Open Browser**
```
URL: http://localhost:3000/research-paper-editor.html
```

**3. Fill Form**
```
Student ID:    test-student-123
Student Name:  Test Student
Paper Title:   Test Paper Upload
Chapter:       1
Part:          Introduction
File:          (Select any PDF file)
```

**4. Submit**
Click "Submit" button

### Expected Results

**Browser Console (F12 → Console tab):**
```
✅ Submission created successfully!
Submission ID: 1 (or higher number)
```

**Supabase Table Editor:**
```
Submissions table → should show new row:
├─ id: 1 (or next number)
├─ student_id: test-student-123
├─ student_name: Test Student
├─ paper_title: Test Paper Upload
├─ chapter: 1
├─ part: Introduction
├─ status: pending
└─ created_at: 2026-01-30 (current date)
```

**Supabase Storage:**
```
Storage → research-papers → should see new files:
└─ Some path like: 1/1/test.pdf
```

### Troubleshooting Upload

**Problem:** "Upload failed - Network error"
- **Cause:** Server not running or connection refused
- **Solution:**
  ```powershell
  taskkill /IM node.exe /F
  node server/server.js
  ```

**Problem:** "Error: SUPABASE_URL not defined"
- **Cause:** `.env` file not loaded or not in correct directory
- **Solution:**
  1. Verify `.env` exists in: `c:\Users\ADMIN\researchProject (LATEST)\.env`
  2. Not in `server/` folder!
  3. Restart server

**Problem:** "File uploaded but not visible in Storage"
- **Cause:** Bucket not public OR file size too large
- **Solution:**
  1. Verify bucket is public (Storage → Settings)
  2. Check file size < 50MB
  3. Refresh browser

**Problem:** "New row appears in database but no file in Storage"
- **Cause:** Upload to database succeeded but file upload failed
- **Solution:**
  1. Check browser console for specific error
  2. Verify storage bucket exists and is public
  3. Check `.env` SUPABASE_ANON_KEY is correct

---

## Step 4: Service Key Rotation

### Why Rotate?
Your service key JWT was pasted in a chat - anyone with it can access your Supabase project!

### Where to Find Settings
```
Supabase Dashboard
├─ Bottom left: Settings icon ⚙️ ← CLICK HERE
├─ Left menu: API ← CLICK HERE
└─ URL: https://app.supabase.com/project/<id>/settings/api
```

### Rotation Steps

**1. View Current Keys**
```
Settings → API page shows:
├─ Project API Keys section
│  └─ Service Role Secret (long key starting with eyJhbGci...)
└─ This is what we need to regenerate
```

**2. Regenerate Key**
```
Service Role Secret section
├─ Click "Regenerate" button ← CLICK HERE
├─ Confirmation dialog: "Are you sure?"
└─ Click "Regenerate" to confirm
```

**3. Copy New Key**
```
⚠️ IMPORTANT: Copy the new key IMMEDIATELY
(It won't be shown again unless you regenerate again)
```

**4. Update `.env` File**
```powershell
# In project root directory
cat .env  # Shows current values

# Edit .env with your new key
SUPABASE_SERVICE_ROLE_KEY=<paste_new_key_here>
```

**5. Restart Server**
```powershell
taskkill /IM node.exe /F
node server/server.js
```

### Verify Rotation Successful
```
Server output should show:
✅ Supabase endpoints mounted at /api
(If there's an error about invalid key, rotation failed)
```

### Common Issues

**Problem:** "Old key still works after regeneration"
- **Cause:** Normal - old key takes a minute to invalidate
- **Solution:** Wait 1-2 minutes and try again

**Problem:** "New key causes server errors"
- **Cause:** Key wasn't fully copied or pasted
- **Solution:**
  1. Go back to Supabase Settings → API
  2. Regenerate again
  3. Copy very carefully (use Ctrl+A to select all)
  4. Paste into `.env`

**Problem:** "Forgot to copy new key before navigating away"
- **Cause:** Supabase doesn't show old keys
- **Solution:** 
  1. Go back to API Settings
  2. Regenerate again
  3. Copy immediately

---

## Summary Checklist

After all 4 steps, you should have:

```
✅ 6 database tables created
   └─ submissions, revisions, timelines, groups, group_members, notifications

✅ Storage bucket created and public
   └─ research-papers (public access)

✅ Upload test successful
   └─ Test file appears in database and storage

✅ Service key rotated
   └─ New key in .env and server running
```

---

## Quick Troubleshooting Matrix

| Symptom | Cause | Solution |
|---------|-------|----------|
| Tables not appearing | Schema not executed | Run SQL in SQL Editor |
| Upload fails with 404 | Server not running | `node server/server.js` |
| Upload succeeds but no file | Bucket not public | Storage → Settings → Public |
| "SUPABASE_URL not defined" | .env in wrong location | Must be in project root, not server/ |
| File visible in storage but can't download | Bucket not public | Change bucket access to Public |
| Server won't start after key rotation | New key has typo | Regenerate and copy carefully |
| Query editor won't show results | Multiple queries pasted | Only paste and run one query at a time |

---

## Performance Tips

Once everything is working:

1. **Optimize Table Queries**
   - Use indexes: Queries on `student_id`, `status`, `chapter/part` are fast
   - Add WHERE clauses when fetching data

2. **Storage Optimization**
   - Archive old PDFs after 6 months
   - Use file naming: `{chapter}/{part}/{timestamp}.pdf`

3. **Database Backups**
   - Supabase auto-backs up daily
   - No action needed from you

4. **Monitoring**
   - Supabase Dashboard → Logs shows all API calls
   - Monitor storage usage: Storage tab shows total size

---

**Status:** Ready for implementation
**Time Estimate:** 15 minutes total
**Difficulty:** Beginner-friendly (copy-paste + clicking)
