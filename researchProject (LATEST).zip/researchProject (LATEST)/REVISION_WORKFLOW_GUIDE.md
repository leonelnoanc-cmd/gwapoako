# Revision Workflow Integration Guide

## Overview
This document explains the complete workflow for submitting revisions, comparing papers, and managing feedback between students and advisers.

## Complete Workflow

### Step 1: Adviser Requests Revision (in group-dashboard.html)
1. Adviser logs in and views **group-dashboard.html**
2. Adviser navigates to **Submissions** tab
3. Adviser clicks "Request Revision" button on a submitted chapter part
4. System updates part status to `'revise'`

### Step 2: Student Views Revision Request & Makes Changes
1. Student sees notification: "Revision requested for [Chapter] - [Part]"
2. Student clicks on the part requiring revision
3. Student is transported to **revise-paper-student.html** with chapter and part in URL parameters:
   ```
   revise-paper-student.html?chapter=Chapter%202&part=Review%20of%20Related%20Literature
   ```

### Step 3: Student Submits Revised Work
1. Student edits their work in the Quill editor on **revise-paper-student.html**
2. Student clicks **"💾 Save & Submit Revisions"** button
3. System performs the following:
   - ✅ Saves revised content to `localStorage.revisedSubmissions`
   - ✅ Creates adviser notification in `localStorage.adviserRevisionNotifications`
   - ✅ Stores revision with metadata:
     ```json
     {
       "chapter": "Chapter 2",
       "part": "Review of Related Literature",
       "revisedContent": "...HTML from Quill...",
       "revisedAt": "2026-01-25T10:30:00Z",
       "revisedBy": "John Doe",
       "groupMembers": ["John Doe", "Jane Smith"]
     }
     ```
   - ✅ Shows confirmation alert: "✓ Revisions saved successfully!"
   - ✅ Automatically navigates to **paper-comparison.html** with parameters:
     ```
     paper-comparison.html?chapter=Chapter%202&part=Review%20of%20Related%20Literature
     ```

### Step 4: Adviser Reviews Side-by-Side Comparison
1. Adviser receives notification about revision submission
2. From **group-dashboard.html**, adviser clicks on a chapter part
3. System checks user role (adviser) and navigates to **revise-paper-student.html**
   - Adviser can view and optionally edit the revised content
4. Adviser can click a button to view comparison or navigate to **paper-comparison.html**
5. On **paper-comparison.html**, adviser sees:
   - **Left Panel (📄 Draft Version)**: Original submitted work
   - **Right Panel (✏️ Revised Version)**: Student's revised submission
6. Adviser can:
   - Highlight text in revised version
   - Add comments/feedback
   - Approve revision (marks status as 'complete')

### Step 5: Back Navigation
- From **revise-paper-student.html**:
  - If logged in as **adviser**: "Cancel" button → returns to **group-dashboard.html**
  - If logged in as **student**: "Cancel" button → returns to **Student_dashboard.html** or **Student-leader.html**
- From **paper-comparison.html**: "Back" button → returns to **group-dashboard.html**

## Data Flow & Storage

### Key localStorage Keys:

1. **revisedSubmissions** (JSON Object)
   ```
   {
     "Chapter 2_Review of Related Literature": [
       { revised content object },
       { another revision }
     ],
     "Chapter 3_Research Design": [...]
   }
   ```

2. **adviserRevisionNotifications** (JSON Array)
   ```
   [
     {
       "id": "1705925400000",
       "chapter": "Chapter 2",
       "part": "Review of Related Literature",
       "revisedBy": "John Doe",
       "revisedAt": "2026-01-25T10:30:00Z",
       "status": "new",
       "message": "Revision submitted for Chapter 2 - Review of Related Literature"
     }
   ]
   ```

3. **partStatus** (JSON Object)
   - Stores status of each part: 'pending', 'submitted', 'revise', 'complete'
   - Key format: `"Chapter X_Part Name"`
   - Values: `'pending'`, `'submitted'`, `'revise'`, `'complete'`

## Implementation Details

### Files Modified:

#### 1. revise-paper-student.html
**Changes:**
- `saveRevision()` function now:
  - Extracts chapter and part from URL parameters
  - Saves to `revisedSubmissions` localStorage
  - Creates adviser notifications
  - Redirects to `paper-comparison.html` instead of going back

- `goBack()` function now:
  - Checks user role
  - Advisers return to `group-dashboard.html`
  - Students return to their respective dashboards

#### 2. paper-comparison.html
**Changes:**
- `loadContent()` function now:
  - Displays original content on **left panel**
  - Displays revised content on **right panel**
  - Clearly separates both versions for comparison

- New `getRevisedContentNew()` function:
  - Retrieves latest revision from `revisedSubmissions` storage
  - Returns full revision object with metadata

- `getRevisedContent()` function (legacy):
  - Maintained for backward compatibility
  - Checks multiple storage locations

#### 3. group-dashboard.html
**Changes:**
- `openPaperViewer()` function now:
  - Checks user role at the start
  - If adviser: navigates to `revise-paper-student.html` with chapter/part params
  - If student and part status is 'revise': navigates to `paper-comparison.html`
  - Otherwise: opens modal viewer as before

## URL Parameters Convention

All navigation between revision pages uses standardized URL parameters:

```
?chapter=[Chapter Name]&part=[Part Name]
```

**Examples:**
```
revise-paper-student.html?chapter=Chapter%202&part=Review%20of%20Related%20Literature
paper-comparison.html?chapter=Chapter%202&part=Review%20of%20Related%20Literature
```

Parameters are URL-encoded using `encodeURIComponent()` and decoded in target pages using URL parameters parsing.

## Role-Based Behavior

### Student Flow:
```
Student clicks part in dashboard
         ↓
Draft/Submit page (if new submission)
         ↓
Adviser requests revision
         ↓
revise-paper-student.html (notified)
         ↓
Save & Submit Revisions
         ↓
paper-comparison.html (to view changes)
```

### Adviser Flow:
```
Adviser reviews submissions in group-dashboard.html
         ↓
Click chapter part
         ↓
revise-paper-student.html (view/edit revision request)
         ↓
Request Revision (mark as 'revise')
         ↓
Student submits revision
         ↓
adviser notified
         ↓
Click part again → revise-paper-student.html (view revised work)
         ↓
Or open paper-comparison.html (see side-by-side)
         ↓
Approve/Reject revision
```

## Key Features

✅ **Automatic Notifications**
- Adviser notified immediately when revision is submitted
- Notifications stored in localStorage for persistence

✅ **Side-by-Side Comparison**
- Original and revised versions displayed simultaneously
- Easy to identify changes

✅ **Revision History**
- Multiple revisions per part stored as array
- Latest revision always retrieved first
- Full metadata preserved (timestamp, author, etc.)

✅ **Status Tracking**
- Part status changes: pending → revise → complete
- Visual indicators in dashboard (colors, icons)

✅ **Role-Based Navigation**
- Advisers, students, and leaders have different flows
- URLs carry context (chapter/part info)
- Consistent back navigation

## Testing Checklist

- [ ] Student receives revision request notification
- [ ] Student navigates to revise-paper-student.html with correct URL params
- [ ] Student makes edits and clicks "Save & Submit Revisions"
- [ ] Revised content saved to localStorage.revisedSubmissions
- [ ] Notification created in localStorage.adviserRevisionNotifications
- [ ] Page auto-redirects to paper-comparison.html
- [ ] Adviser receives notification
- [ ] Adviser can view original (left) and revised (right) on paper-comparison.html
- [ ] From group-dashboard, adviser can navigate to revise-paper-student.html
- [ ] Highlight and commenting works on revised version
- [ ] Approve/Reject buttons update part status
- [ ] Back buttons navigate to correct pages based on role
- [ ] URL parameters persist through page navigation
- [ ] Multiple revisions stored properly (array structure)

## Future Enhancements

1. **Real-time Collaboration**
   - WebSocket for live notifications instead of polling
   - Real-time presence indicators

2. **Version History**
   - Show timeline of all revisions
   - Ability to compare any two versions

3. **Advanced Diff View**
   - Visual highlighting of differences
   - Track deletions/additions/modifications

4. **Comments & Replies**
   - Threaded conversations
   - Comment resolution workflow

5. **Mobile Responsiveness**
   - Stack panels vertically on small screens
   - Swipe navigation between versions

---

**Last Updated:** January 25, 2026  
**Status:** ✅ Implementation Complete
