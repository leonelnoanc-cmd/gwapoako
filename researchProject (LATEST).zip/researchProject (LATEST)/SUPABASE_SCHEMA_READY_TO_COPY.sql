-- ============================================
-- Supabase Schema for Research Paper System
-- ============================================

-- 1. SUBMISSIONS TABLE
-- Stores paper submissions with tracking
CREATE TABLE submissions (
  id BIGSERIAL PRIMARY KEY,
  student_id UUID NOT NULL,
  student_name TEXT,
  paper_title TEXT NOT NULL,
  chapter INTEGER NOT NULL,
  part TEXT NOT NULL,
  file_url TEXT,
  file_size INTEGER,
  status TEXT DEFAULT 'pending',
  submitted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_submissions_student_id ON submissions(student_id);
CREATE INDEX idx_submissions_status ON submissions(status);
CREATE INDEX idx_submissions_chapter_part ON submissions(chapter, part);

-- 2. REVISIONS TABLE
CREATE TABLE revisions (
  id BIGSERIAL PRIMARY KEY,
  submission_id BIGINT REFERENCES submissions(id),
  revision_number INTEGER DEFAULT 1,
  adviser_feedback TEXT,
  requested_at TIMESTAMP DEFAULT NOW(),
  revised_file_url TEXT,
  revised_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_revisions_submission_id ON revisions(submission_id);

-- 3. TIMELINES TABLE
CREATE TABLE timelines (
  id BIGSERIAL PRIMARY KEY,
  adviser_id UUID NOT NULL,
  title TEXT NOT NULL,
  due_date DATE NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_timelines_adviser_id ON timelines(adviser_id);
CREATE INDEX idx_timelines_due_date ON timelines(due_date);

-- 4. GROUPS TABLE
CREATE TABLE groups (
  id BIGSERIAL PRIMARY KEY,
  section_id BIGINT,
  group_name TEXT NOT NULL,
  adviser_id UUID,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_groups_section_id ON groups(section_id);

-- 5. GROUP MEMBERS TABLE
CREATE TABLE group_members (
  id BIGSERIAL PRIMARY KEY,
  group_id BIGINT REFERENCES groups(id),
  student_id UUID NOT NULL,
  role TEXT DEFAULT 'member',
  joined_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_group_members_group_id ON group_members(group_id);
CREATE INDEX idx_group_members_student_id ON group_members(student_id);

-- 6. NOTIFICATIONS TABLE
CREATE TABLE notifications (
  id BIGSERIAL PRIMARY KEY,
  recipient_id UUID NOT NULL,
  notification_type TEXT,
  related_submission_id BIGINT,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_recipient_id ON notifications(recipient_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- ============================================
-- DONE! All tables created.
-- Do not run the RLS policies below unless you need row-level security
-- ============================================
