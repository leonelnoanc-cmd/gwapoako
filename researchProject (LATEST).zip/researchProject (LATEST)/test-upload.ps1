$url = 'http://localhost:3000/api/submissions/upload'
$file = 'C:\temp\test.pdf'
$form = @{
    student_id = 'test-student-123'
    student_name = 'Test Student'
    paper_title = 'Test Paper'
    chapter = '1'
    part = 'Introduction'
    file = Get-Item -Path $file
}
try {
    $response = Invoke-RestMethod -Uri $url -Method Post -Form $form
    Write-Host 'Upload Success!'
    $response | ConvertTo-Json
} catch {
    Write-Host 'Error: ' $_.Exception.Message
}
