# 🎯 Supabase Setup & Configuration - Master Guide

**Project:** Research Paper Submission System  
**Supabase Project:** wgnbejkryaswxvvhmaff  
**Status:** Fixed and Ready for Configuration  
**Last Updated:** January 30, 2026

---

## 📚 Documentation Index

| Document | Purpose | Read When |
|----------|---------|-----------|
| **SUPABASE_FIX_GUIDE.md** | Complete fix checklist | Server not working |
| **SUPABASE_TROUBLESHOOTING.md** | Problem diagnosis & fixes | Specific errors occur |
| **SUPABASE_FINAL_SETUP_GUIDE.md** | Step-by-step manual setup | First time configuration |
| **This Document** | Overview & quick reference | Getting oriented |

---

## 🚀 Quick Start (5 minutes)

### Step 1: Install Dependencies
```powershell
cd server
npm install
```

### Step 2: Start Server
```powershell
node server.js
```

**Expected output:**
```
✅ SERVER STARTED SUCCESSFULLY
📍 URL: http://localhost:3000
✅ Supabase endpoints mounted at /api
```

### Step 3: Verify Setup
- Open: http://localhost:3000/health
- Should show: `{"status":"OK","message":"Server is running"}`

---

## ✅ Complete Setup Checklist

Use this to verify everything is working:

### Server Setup
- [ ] Node.js installed (v14+)
- [ ] npm dependencies installed: `npm install` in server/
- [ ] .env file exists in project root with credentials
- [ ] Server starts without errors: `node server.js`
- [ ] Health check works: http://localhost:3000/health

### Supabase Configuration
- [ ] Project created: wgnbejkryaswxvvhmaff
- [ ] 6 tables created:
  - [ ] submissions
  - [ ] revisions
  - [ ] timelines
  - [ ] groups
  - [ ] group_members
  - [ ] notifications
- [ ] Storage bucket "research-papers" created
- [ ] Bucket set to "Public" access
- [ ] Service role key is current (rotated if exposed)

### Testing
- [ ] Server running on http://localhost:3000
- [ ] API endpoints accessible at /api/*
- [ ] Can submit test paper
- [ ] File appears in Supabase Storage
- [ ] Record appears in submissions table

---

## 🔧 Setup Sequence

Follow these steps in order:

### 1. Install Dependencies (5 min)
```powershell
cd "C:\Users\ADMIN\researchProject (LATEST)\server"
npm install
```

### 2. Configure Environment (2 min)
- .env file must be in PROJECT ROOT (not server/)
- Must contain:
  - SUPABASE_URL
  - SUPABASE_ANON_KEY
  - SUPABASE_SERVICE_ROLE_KEY
  - PORT=3000

### 3. Create Database Tables (5 min)
Go to: https://app.supabase.com
1. Select project: wgnbejkryaswxvvhmaff
2. SQL Editor → New Query
3. Copy from: SUPABASE_SCHEMA_READY_TO_COPY.sql
4. Paste and click "Run"
5. Verify 6 tables appear in Table Editor

### 4. Configure Storage (3 min)
Go to: https://app.supabase.com
1. Select project: wgnbejkryaswxvvhmaff
2. Storage → Click bucket "research-papers"
3. Settings → Access Control → Set to "Public"
4. Click "Save"

### 5. Rotate Service Key (3 min)
Go to: https://app.supabase.com
1. Select project: wgnbejkryaswxvvhmaff
2. Settings → API → Service Role Secret
3. Click "Regenerate"
4. Copy NEW key
5. Update .env: SUPABASE_SERVICE_ROLE_KEY=<new_key>

### 6. Start Server (2 min)
```powershell
cd "C:\Users\ADMIN\researchProject (LATEST)"
node server/server.js
```

### 7. Test Upload (5 min)
1. Open: http://localhost:3000/research-paper-editor.html
2. Fill form with test data
3. Upload PDF
4. Verify success message
5. Check Supabase Dashboard for data

---

## 📍 Key Configuration Values

```
PROJECT DETAILS:
├─ Project ID: wgnbejkryaswxvvhmaff
├─ URL: https://wgnbejkryaswxvvhmaff.supabase.co
├─ Region: (check in dashboard)
└─ Plan: Free Tier

SERVER:
├─ Host: localhost
├─ Port: 3000
├─ API Base: http://localhost:3000/api
└─ Health Check: http://localhost:3000/health

DATABASE:
├─ Tables: 6 total
├─ Primary: submissions
└─ Status: Ready

STORAGE:
├─ Bucket: research-papers
├─ Access: Public
└─ Max Size: 50MB per file

LIMITS (Free Tier):
├─ Storage: 1 GB
├─ Database: 500 MB
├─ API Calls: 2M/month
└─ Users: Unlimited
```

---

## 🐛 Troubleshooting Quick Links

| Issue | Solution |
|-------|----------|
| Server won't start | See SUPABASE_TROUBLESHOOTING.md → Issue: "Port 3000 already in use" |
| Upload fails | See SUPABASE_FIX_GUIDE.md → Step 6: Test Upload Feature |
| Can't see tables | See SUPABASE_TROUBLESHOOTING.md → Issue: "Table does not exist" |
| File not uploading | See SUPABASE_FIX_GUIDE.md → Step 4: Storage Bucket Configuration |
| Connection error | See SUPABASE_FIX_GUIDE.md → Troubleshooting section |

---

## 📊 Architecture Overview

```
Your Application
│
├─ Frontend (HTML + JavaScript)
│  ├─ research-paper-editor.html
│  ├─ supabase-upload.js
│  └─ HTTP Requests
│
├─ Express Server (localhost:3000)
│  ├─ server.js (main)
│  ├─ supabase-endpoints.js (routes)
│  ├─ supabase-client.js (operations)
│  └─ .env (credentials)
│
└─ Supabase Cloud
   ├─ PostgreSQL Database
   │  ├─ submissions
   │  ├─ revisions
   │  ├─ timelines
   │  ├─ groups
   │  ├─ group_members
   │  └─ notifications
   └─ Cloud Storage
      └─ research-papers (public bucket)
```

---

## 🔐 Security Checklist

- [ ] Service role key has been rotated (not exposed in docs)
- [ ] .env file is in .gitignore (not committed to git)
- [ ] Storage bucket access is "Public" (intentional for papers)
- [ ] API keys are environment variables (not hardcoded)
- [ ] No sensitive data in frontend JavaScript
- [ ] CORS is configured correctly (localhost:3000 for development)

---

## 📈 Performance Tips

1. **Database Optimization:**
   - Indexes are created on common queries
   - Queries return only needed fields
   - Use pagination for large result sets

2. **Storage Optimization:**
   - PDF files are compressed before upload
   - Files are organized by student ID
   - Metadata is stored in database

3. **Server Optimization:**
   - Connection pooling is enabled
   - Requests are logged for debugging
   - Error handling is comprehensive

---

## 🎯 Next Steps After Setup

### Immediate (After verification):
1. Test with real student submissions
2. Monitor error logs
3. Verify data appears in dashboard

### Short Term (Next week):
1. Integrate upload into all HTML pages
2. Add submission status display
3. Build adviser dashboard queries

### Medium Term (Next month):
1. Add revision workflow
2. Implement notifications
3. Create analytics reports

---

## 📞 Support Resources

### Official Supabase Documentation
- Dashboard: https://app.supabase.com
- Docs: https://supabase.com/docs
- Community: https://supabase.com/community

### Your Project Resources
- **Code Files:** server/supabase-client.js, server/supabase-endpoints.js
- **Database Schema:** SUPABASE_SCHEMA_READY_TO_COPY.sql
- **Frontend Module:** supabase-upload.js
- **Configuration:** .env file

### Diagnostic Tools
- Verification script: `node server/verify-setup.js`
- Startup script: `node server/start-server.js`
- Health check: `http://localhost:3000/health`

---

## 🔄 Common Commands

```powershell
# Start server with verification
node server/start-server.js

# Verify setup
node server/verify-setup.js

# Check port is free
netstat -ano | findstr 3000

# Kill node process if stuck
taskkill /IM node.exe /F

# Install/update dependencies
npm install

# Check environment is configured
Get-Content .env

# Test API health
Invoke-WebRequest http://localhost:3000/health -UseBasicParsing
```

---

## ✨ What's Included in This Fix

### New/Enhanced Files:
- **server/server.js** - Enhanced with better error handling and logging
- **server/verify-setup.js** - Diagnostic script to check configuration
- **server/start-server.js** - Smart startup with health checks
- **SUPABASE_FIX_GUIDE.md** - Complete step-by-step fix guide
- **SUPABASE_TROUBLESHOOTING.md** - Problem diagnosis and solutions
- **This document** - Master guide and overview

### Improvements Made:
✅ Better error messages on startup
✅ Supabase endpoint mounting with verification
✅ Environment configuration validation
✅ Port availability checking
✅ Comprehensive troubleshooting guides
✅ Quick diagnostic tools

---

## 🎓 Learning Resources

If you want to understand how it works:

1. **Express Server Basics:** server/server.js
2. **Supabase Integration:** server/supabase-client.js
3. **API Endpoints:** server/supabase-endpoints.js
4. **Frontend Upload:** supabase-upload.js
5. **Database Schema:** SUPABASE_SCHEMA_READY_TO_COPY.sql

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Jan 30, 2026 | Initial setup complete |
| 1.1 | Jan 30, 2026 | Added comprehensive fix guide |
| 1.2 | Jan 30, 2026 | Added troubleshooting & diagnostic tools |

---

## 🎉 Completion Criteria

Your Supabase setup is complete when:

- ✅ Server starts without errors
- ✅ All 6 database tables exist
- ✅ Storage bucket is created and public
- ✅ Upload feature works end-to-end
- ✅ Data appears in Supabase Dashboard
- ✅ Service key has been rotated

---

**Ready to begin? Start with:** SUPABASE_FIX_GUIDE.md

**Having issues? Check:** SUPABASE_TROUBLESHOOTING.md

**Need details? Read:** SUPABASE_FINAL_SETUP_GUIDE.md

---

**Status: ✅ Ready for Configuration**  
**Last Verified:** January 30, 2026
