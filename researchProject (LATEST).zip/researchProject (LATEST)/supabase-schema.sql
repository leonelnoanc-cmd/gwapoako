-- ============================================
-- Supabase Schema for Research Paper System
-- ============================================

-- 1. SUBMISSIONS TABLE
-- Stores paper submissions with tracking
CREATE TABLE submissions (
  id BIGSERIAL PRIMARY KEY,
  student_id UUID NOT NULL,
  student_name TEXT,
  paper_title TEXT NOT NULL,
  chapter INTEGER NOT NULL,
  part TEXT NOT NULL,
  file_url TEXT,  -- Public URL to PDF
  file_size INTEGER,  -- Bytes
  status TEXT DEFAULT 'pending',  -- pending, in-review, approved, rejected, revised
  submitted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Index for fast queries
CREATE INDEX idx_submissions_student_id ON submissions(student_id);
CREATE INDEX idx_submissions_status ON submissions(status);
CREATE INDEX idx_submissions_chapter_part ON submissions(chapter, part);

-- 2. REVISIONS TABLE
-- Tracks revision requests and resubmissions
CREATE TABLE revisions (
  id BIGSERIAL PRIMARY KEY,
  submission_id BIGINT REFERENCES submissions(id),
  revision_number INTEGER DEFAULT 1,
  adviser_feedback TEXT,
  requested_at TIMESTAMP DEFAULT NOW(),
  revised_file_url TEXT,
  revised_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_revisions_submission_id ON revisions(submission_id);

-- 3. TIMELINES TABLE
-- Research timeline events
CREATE TABLE timelines (
  id BIGSERIAL PRIMARY KEY,
  adviser_id UUID NOT NULL,
  title TEXT NOT NULL,
  due_date DATE NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_timelines_adviser_id ON timelines(adviser_id);
CREATE INDEX idx_timelines_due_date ON timelines(due_date);

-- 4. GROUPS TABLE
-- Student groups within sections
CREATE TABLE groups (
  id BIGSERIAL PRIMARY KEY,
  section_id BIGINT,
  group_name TEXT NOT NULL,
  adviser_id UUID,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_groups_section_id ON groups(section_id);

-- 5. GROUP MEMBERS TABLE
-- Maps students to groups
CREATE TABLE group_members (
  id BIGSERIAL PRIMARY KEY,
  group_id BIGINT REFERENCES groups(id),
  student_id UUID NOT NULL,
  role TEXT DEFAULT 'member',  -- member, leader
  joined_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_group_members_group_id ON group_members(group_id);
CREATE INDEX idx_group_members_student_id ON group_members(student_id);

-- 6. NOTIFICATIONS TABLE
-- Real-time notifications for adviser/students
CREATE TABLE notifications (
  id BIGSERIAL PRIMARY KEY,
  recipient_id UUID NOT NULL,
  notification_type TEXT,  -- submission, revision, deadline, comment
  related_submission_id BIGINT,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_recipient_id ON notifications(recipient_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- ============================================
-- Enable Row Level Security (Optional)
-- ============================================

-- Students can only see their own submissions
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students view own submissions"
  ON submissions
  FOR SELECT
  USING (student_id = auth.uid());

-- Advisers can see all submissions
CREATE POLICY "Advisers view all submissions"
  ON submissions
  FOR SELECT
  USING (auth.uid() IN (SELECT adviser_id FROM groups));

-- ============================================
-- Sample Data (Optional - for testing)
-- ============================================

-- INSERT INTO submissions (student_id, student_name, paper_title, chapter, part, status)
-- VALUES (
--   'student-123'::uuid,
--   'John Doe',
--   'Introduction to AI',
--   1,
--   'Background of the Study',
--   'pending'
-- );
