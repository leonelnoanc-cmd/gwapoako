# Research Paper Organization
(Aligned with GSC SPED Integrated School – Practical Research)

## Chapter I – INTRODUCTION
- Background of the Study
- Statement of the Problem
  - General Problem
  - Specific Problems
- Conceptual Framework
- Theoretical Framework
- Significance of the Study
- Scope and Delimitation of the Study
- Definition of Terms

## Chapter II – REVIEW OF RELATED LITERATURE AND STUDIES
### Review of Related Literature
- Local Literature
- Foreign Literature

### Review of Related Studies
- Local Studies
- Foreign Studies

## Chapter III – METHODOLOGY
- Research Design
- Locale of the Study
- Research Instrument
- Participants / Respondents of the Study
- Data Gathering Procedures
- Method of Data Analysis

## Chapter IV – PRESENTATION, ANALYSIS, AND INTERPRETATION OF FINDINGS
- Presentation of Findings
- Analysis of Data
- Interpretation of Results
- Discussion of Findings

## Chapter V – SUMMARY, CONCLUSION, AND RECOMMENDATIONS
- Summary of Findings
- Conclusions
- Recommendations

## References
- APA format

## Appendices
- Letter to the Principal
- Letter to the Participants
- Consent Form
- Questionnaire / Interview Guide
- Certificates (Validation, Grammarian, etc.)

## Writing Rules
- Follow chapter order strictly
- Write ONE section at a time
- Use academic and formal tone
- Third-person perspective
- No results in Chapters I–III
- No new literature in Chapters IV–V
