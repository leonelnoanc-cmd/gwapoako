# Supabase Project Configuration Reference

## Project Information

**Project Name:** Research Paper Submission System
**Supabase Project ID:** wgnbejkryaswxvvhmaff
**Project URL:** https://wgnbejkryaswxvvhmaff.supabase.co
**Region:** (Check in Supabase Dashboard)

---

## Connection Credentials

### Local .env File Location
```
c:\Users\ADMIN\researchProject (LATEST)\.env
(DO NOT commit to Git - already in .gitignore)
```

### Current Credentials (in .env)
```env
SUPABASE_URL=https://wgnbejkryaswxvvhmaff.supabase.co
SUPABASE_ANON_KEY=sb_publishable_zXDoUv_8UPOOm_rSzxNyjg_d_GPDquW
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndnbmJlamtyeWFzd3h2dmhtYWZmIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2OTcyNTY3MywiZXhwIjoyMDg1MzAxNjczfQ.VHpHfuKOT2IClj7GAy5p36RcEYbyamTAjURi9YZflsc
PORT=3000
ANTHROPIC_API_KEY=
```

⚠️ **IMPORTANT:** Service role key is exposed. Rotate after testing!

---

## API Endpoints

### Base URL
```
http://localhost:3000/api
```

### Available Endpoints

#### Submissions
```
POST   /submissions/upload
GET    /submissions/:studentId
GET    /submissions/:id/status
PATCH  /submissions/:id/status
```

#### Revisions
```
POST   /revisions/:submissionId/request
GET    /revisions/:submissionId
```

#### Timeline
```
POST   /timeline
GET    /timeline
```

#### Notifications
```
POST   /notifications
GET    /notifications/:recipientId
PATCH  /notifications/:id/read
```

---

## Database Schema

### Tables to Create (Execute in SQL Editor)

1. **submissions** - Paper submissions
   - Columns: id, student_id, student_name, paper_title, chapter, part, file_url, status
   - Indexes: student_id, status, chapter+part

2. **revisions** - Revision requests
   - Columns: id, submission_id, revision_number, adviser_feedback, revised_file_url
   - Index: submission_id

3. **timelines** - Research deadlines
   - Columns: id, adviser_id, title, due_date, description
   - Indexes: adviser_id, due_date

4. **groups** - Student groups
   - Columns: id, section_id, group_name, adviser_id
   - Index: section_id

5. **group_members** - Group membership
   - Columns: id, group_id, student_id, role
   - Indexes: group_id, student_id

6. **notifications** - System notifications
   - Columns: id, recipient_id, notification_type, related_submission_id, message, is_read
   - Indexes: recipient_id, is_read

### How to Create
```
1. Supabase Dashboard → SQL Editor
2. Click "New Query"
3. Copy from: SUPABASE_SCHEMA_READY_TO_COPY.sql
4. Paste and Run
```

---

## Storage Configuration

### Bucket Name
```
research-papers
```

### Bucket Settings
- **Access Level:** Public (MUST be public for downloads)
- **File Size Limit:** 50MB (default)
- **Allowed Types:** All (no restriction)

### File Structure
```
research-papers/
├─ {chapter}/
│  ├─ {part}/
│  │  ├─ {timestamp}.pdf
│  │  └─ {timestamp}.pdf
│  └─ {part}/
└─ {chapter}/
```

### Example File Path
```
https://wgnbejkryaswxvvhmaff.supabase.co/storage/v1/object/public/research-papers/1/Introduction/1706553600.pdf
```

---

## Server Configuration

### Port
```
3000
```

### Server Location
```
c:\Users\ADMIN\researchProject (LATEST)\server\server.js
```

### To Start
```powershell
cd "c:\Users\ADMIN\researchProject (LATEST)"
node server/server.js
```

### Expected Output
```
[dotenv@17.2.3] injecting env (5) from ..\.env
✅ Supabase endpoints mounted at /api
✅ Server running on http://localhost:3000
```

---

## Frontend Integration

### Upload Module
```javascript
// File: supabase-upload.js
class PaperUploader {
  constructor()
  upload(data)
  getSubmissions(studentId)
  getPendingSubmissions(studentId)
  updateStatus(submissionId, newStatus)
  requestRevision(submissionId, feedback)
}
```

### Usage Example
```javascript
const uploader = new PaperUploader();

uploader.upload({
  student_id: 'student-123',
  student_name: 'John Doe',
  paper_title: 'My Research',
  chapter: 1,
  part: 'Introduction',
  file: fileObject
}).then(result => {
  console.log('✅ Uploaded:', result.id);
}).catch(error => {
  console.error('❌ Error:', error.message);
});
```

---

## Testing Credentials

### Test Upload
```javascript
{
  student_id: 'test-student-123',
  student_name: 'Test Student',
  paper_title: 'Test Paper Upload',
  chapter: 1,
  part: 'Introduction',
  file: <any PDF file>
}
```

### Expected Result
```json
{
  "success": true,
  "id": 1,
  "file_url": "https://wgnbejkryaswxvvhmaff.supabase.co/storage/v1/object/public/research-papers/1/1/test.pdf"
}
```

---

## Security

### Keys Overview

| Key | Type | Location | Usage |
|-----|------|----------|-------|
| Anon Key | Public | `.env` | Frontend requests (public data) |
| Service Role | Secret | `.env` | Server requests (admin operations) |
| JWT | Bearer Token | Authorization header | API authentication |

### Key Rotation Process

1. **When:** After key exposure or regularly (monthly recommended)
2. **Where:** Supabase → Settings → API → Regenerate
3. **Steps:**
   - Copy new key immediately
   - Update `.env` file
   - Restart server
   - Discard old key

### IMPORTANT
⚠️ Your service key was pasted in chat during setup. ROTATE IT IMMEDIATELY after testing!

---

## Monitoring & Maintenance

### View Logs
```
Supabase Dashboard → Logs
Shows all API calls, errors, and performance
```

### Database Backups
```
Supabase Dashboard → Backups
Automatic daily backups (no action needed)
```

### Storage Usage
```
Supabase Dashboard → Storage
Shows total storage used
```

### Performance Metrics
```
Supabase Dashboard → Analytics
Query performance and usage statistics
```

---

## Troubleshooting Reference

### Connection Issues
```
Error: "Cannot connect to Supabase"
Solution: 
  1. Check .env file exists in project root
  2. Verify SUPABASE_URL and keys are correct
  3. Check internet connection
  4. Verify project is not disabled
```

### Upload Issues
```
Error: "File upload failed"
Solution:
  1. Verify storage bucket is PUBLIC
  2. Check file size < 50MB
  3. Ensure bucket name is: research-papers
  4. Check server is running
```

### Query Errors
```
Error: "Table does not exist"
Solution:
  1. Run database schema in SQL Editor
  2. Verify all 6 tables appear in Table Editor
  3. Check for typos in table names
```

### Authentication Errors
```
Error: "Invalid API key"
Solution:
  1. Verify .env has correct keys
  2. Check keys match Supabase Settings → API
  3. If changed, restart server
  4. Try regenerating keys if still failing
```

---

## Performance Optimization

### Indexes Created
```sql
idx_submissions_student_id
idx_submissions_status
idx_submissions_chapter_part
idx_revisions_submission_id
idx_timelines_adviser_id
idx_timelines_due_date
idx_groups_section_id
idx_group_members_group_id
idx_group_members_student_id
idx_notifications_recipient_id
idx_notifications_is_read
```

### Query Tips
```javascript
// Fast - uses index
SELECT * FROM submissions WHERE student_id = '123';

// Fast - uses index
SELECT * FROM submissions WHERE status = 'pending';

// Fast - uses index
SELECT * FROM submissions WHERE chapter = 1 AND part = 'Introduction';

// Slow - no index (avoid)
SELECT * FROM submissions WHERE paper_title LIKE '%research%';
```

---

## Related Files

| File | Purpose |
|------|---------|
| `server/server.js` | Express server entry point |
| `server/supabase-client.js` | Supabase operations |
| `server/supabase-endpoints.js` | API routes |
| `supabase-upload.js` | Frontend module |
| `.env` | Configuration (DO NOT COMMIT) |
| `.env.example` | Configuration template |
| `supabase-schema.sql` | Database schema |
| `SUPABASE_SCHEMA_READY_TO_COPY.sql` | Easy copy version |

---

## Quick Reference Links

| Resource | URL |
|----------|-----|
| Supabase Dashboard | https://app.supabase.com/projects |
| Your Project | https://app.supabase.com/project/wgnbejkryaswxvvhmaff |
| SQL Editor | https://app.supabase.com/project/wgnbejkryaswxvvhmaff/sql |
| Table Editor | https://app.supabase.com/project/wgnbejkryaswxvvhmaff/editor |
| Storage | https://app.supabase.com/project/wgnbejkryaswxvvhmaff/storage |
| Settings | https://app.supabase.com/project/wgnbejkryaswxvvhmaff/settings/api |

---

**Last Updated:** January 30, 2026
**Scope:** Complete Supabase integration reference
**Status:** Ready for deployment
