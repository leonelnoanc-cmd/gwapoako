# NGrok Setup Guide

## Prerequisites
Your server runs on **Port 3000**

## Step 1: Install ngrok
If you haven't installed ngrok yet, download it from: https://ngrok.com/download

Or install via Chocolatey (if you have it):
```
choco install ngrok
```

Or install via NPM:
```
npm install -g ngrok
```

## Step 2: Quick Start (Easiest)
Simply run the batch file in the server folder:
```
server/ngrok-setup.bat
```

This will:
- Configure your authtoken automatically
- Start a tunnel on port 3000
- Display your public URL

## Step 3: Manual Setup
If you prefer manual setup:

1. Configure authtoken (one-time):
```
ngrok config add-authtoken 38V7Lc5UQwwZtl6U3NZCwtukGgR_3jHboVu2fTS2Ye7VERtMC
```

2. Start your Express server:
```
cd server
npm install
npm start
```

3. In another terminal, start ngrok:
```
ngrok http 3000
```

## Step 4: Get Your Public URL
Once ngrok is running, you'll see output like:
```
Session Status                online
Account                       [your account]
Version                        [version]
Region                         [region]
Forwarding                     https://xxxx-xx-xxx-xxx-xx.ngrok.io -> http://localhost:3000
```

Your public URL is: **https://xxxx-xx-xxx-xxx-xx.ngrok.io**

## Step 5: Test Your Website
- Open your public URL in a browser
- You should see your website
- All files will be served
- API calls will work through ngrok

## Important Notes
- ⚠️ Keep ngrok running to keep your site online
- ⚠️ Each time you restart ngrok, you'll get a new URL (unless you use a paid plan)
- ✅ Your authtoken is now saved locally on your machine
- ✅ You can share the ngrok URL with others to access your site

## Troubleshooting
- **Port 3000 already in use?** Change PORT in server.js or stop the existing process
- **ngrok not found?** Install it globally: `npm install -g ngrok`
- **Connection refused?** Make sure Express server is running on port 3000
