#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const http = require('http');

// Create form data
const form = new FormData();
form.append('student_id', 'test-student-123');
form.append('student_name', 'Test Student');
form.append('paper_title', 'Test Paper');
form.append('chapter', '1');
form.append('part', 'Introduction');
form.append('file', fs.createReadStream('C:\\temp\\test.pdf'));

// Make request
const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/submissions/upload',
  method: 'POST',
  headers: form.getHeaders()
};

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);
  console.log('Headers:', res.headers);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('Response:', data);
    process.exit(0);
  });
});

req.on('error', (error) => {
  console.error('Error:', error.message);
  process.exit(1);
});

form.pipe(req);
