/**
 * Integration Guide
 * How to add Supabase to your existing Node.js server
 */

// ============================================
// STEP 1: Install Dependencies
// ============================================
// npm install @supabase/supabase-js multer dotenv

// ============================================
// STEP 2: Add to your .env file
// ============================================
/*
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
*/

// ============================================
// STEP 3: Update your server/server.js
// ============================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Import Supabase endpoints
const supabaseEndpoints = require('./supabase-endpoints');

// Register routes
app.use('/api', supabaseEndpoints);

// Your existing routes...
app.get('/api/timeline', (req, res) => {
  // existing timeline endpoint
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
  console.log(`📦 Supabase endpoints available at /api`);
});

// ============================================
// STEP 4: Update your HTML forms
// ============================================

/*
In research-paper-editor.html or submission.html:

<form id="submitPaperForm">
  <input type="text" id="titleInput" placeholder="Paper Title" required>
  <input type="number" id="chapterInput" placeholder="Chapter" required>
  <input type="text" id="partInput" placeholder="Part" required>
  <input type="file" id="fileInput" accept=".pdf" required>
  <button type="button" onclick="submitPaper()">Submit Paper</button>
</form>

<script src="supabase-upload.js"></script>
<script>
  const uploader = new PaperUploader(window.API_SERVER_URL);

  async function submitPaper() {
    const file = document.getElementById('fileInput').files[0];
    const result = await uploader.uploadPaper(file, {
      student_id: localStorage.getItem('userId'),
      student_name: localStorage.getItem('userName'),
      paper_title: document.getElementById('titleInput').value,
      chapter: parseInt(document.getElementById('chapterInput').value),
      part: document.getElementById('partInput').value
    });

    if (result.success) {
      alert('Paper submitted successfully!');
      // Clear form
      document.getElementById('submitPaperForm').reset();
    } else {
      alert('Error: ' + result.error);
    }
  }
</script>
*/

// ============================================
// STEP 5: API Endpoints Available
// ============================================

/*
POST /api/submissions/upload
  Upload a new paper
  Body: FormData { file, student_id, student_name, paper_title, chapter, part }

GET /api/submissions/:studentId
  Get student's submissions
  
GET /api/submissions-pending/all
  Get all pending submissions (adviser)

GET /api/submissions/:submissionId/view
  Get single submission details

PATCH /api/submissions/:submissionId/status
  Update submission status
  Body: { status: "approved|rejected|revised" }

POST /api/revisions/:submissionId/request
  Request revision
  Body: { feedback: "..." }

GET /api/revisions/:submissionId
  Get all revisions for submission

POST /api/timeline
  Create timeline event
  Body: { adviser_id, title, due_date, description }

GET /api/timeline/:adviserId
  Get adviser's timeline events

GET /api/notifications/:userId
  Get unread notifications

PATCH /api/notifications/:notificationId/read
  Mark notification as read
*/

// ============================================
// STEP 6: Testing
// ============================================

/*
1. Create .env with Supabase credentials
2. Run: npm install
3. Run: npm start (or node server/server.js)
4. Test with curl:

# Upload a paper
curl -X POST http://localhost:3000/api/submissions/upload \
  -F "file=@paper.pdf" \
  -F "student_id=student-123" \
  -F "student_name=John Doe" \
  -F "paper_title=Introduction" \
  -F "chapter=1" \
  -F "part=Background"

# Get pending submissions
curl http://localhost:3000/api/submissions-pending/all

# Update status
curl -X PATCH http://localhost:3000/api/submissions/1/status \
  -H "Content-Type: application/json" \
  -d '{"status":"approved"}'
*/

// ============================================
// STEP 7: Database Setup
// ============================================

/*
1. Go to supabase.com → Sign up
2. Create a new project
3. Get your credentials from Settings → API
4. In SQL Editor, paste supabase-schema.sql
5. Click Run
6. Go to Storage → Create bucket "research-papers"
7. Make it Public
8. Add credentials to .env
9. You're ready!
*/

// ============================================
// STEP 8: Monitor Storage Usage
// ============================================

/*
In Supabase Dashboard:
- Database: Settings → Database size
- Storage: Storage tab → research-papers bucket
- Current project: ~300 MB (well within 1 GB free tier!)
*/

module.exports = app;
