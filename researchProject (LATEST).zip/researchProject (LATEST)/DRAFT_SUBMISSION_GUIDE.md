# Draft Submission System - Quick Start Guide

## How It Works

### For Students:
1. **Create your paper** in the Research Paper Editor
2. **Go to Paper Draft** page (draft.html)
3. **Review your draft** - see all submitted chapter parts
4. **Click "📤 Submit Draft"** button
5. ✅ Your draft is sent to your adviser
6. 🔔 Your adviser receives a notification

### For Student Leaders (Group Leaders):
1. **Submit your draft** using the same process as students
2. 🤖 **Automatic Group Submission**: When ALL group members have submitted their drafts:
   - Group is automatically submitted
   - Adviser receives group submission notification
   - All group members are marked as submitted

### For Advisers:
1. **Access Draft Submissions** - Click "📤 Drafts" in the sidebar of your dashboard
2. **View Student Drafts** tab:
   - See all student draft submissions
   - View full draft content (📖 View Draft button)
   - Approve or request changes (✓ Approve button)
3. **View Group Drafts** tab:
   - See auto-submitted group drafts
   - Verify all members submitted
   - Approve group submissions

## Draft Submission Format

Each draft submission includes:
- **Student/Group name** who submitted
- **Submission timestamp** (date & time)
- **Chapter parts** count (number of parts in draft)
- **References** count (number of references included)
- **Status** (Submitted/Approved)

## Approval Process

1. Adviser reviews draft
2. Click ✓ Approve
3. Draft status changes to "Approved"
4. Student receives confirmation
5. Draft can then be converted to official submission

## Notifications

### For Advisers:
- Notified when student submits draft
- Notified when group auto-submits (all members completed)
- Notifications stored in localStorage with:
  - Type (draft_submission / group_draft_submission)
  - Student/Group name
  - Submission timestamp
  - Complete draft data

## Storage

All data is stored in browser localStorage under:
- `adviserDraftSubmissions` - Student draft submissions
- `groupDraftSubmissions` - Group draft submissions  
- `adviserNotifications` - All notifications for adviser

## Files Modified/Added

### Modified:
- **draft.html** - Added Submit Draft button and functionality

### Modified:
- **Adviser_dashboard.html** - Added Drafts sidebar icon

### Modified:
- **section-groups.html** - Added members array to groups

### New Files:
- **adviser-draft-submissions.html** - Full draft submission management page

## Testing the System

### Test 1: Student Draft Submission
1. Login as student
2. Create some content in paper editor
3. Go to draft.html
4. Click "📤 Submit Draft"
5. Verify success message
6. Login as adviser
7. Click "📤 Drafts" - should see student draft

### Test 2: Group Auto-Submit (Advanced)
1. Create a group with multiple members
2. Each member submits their draft individually
3. When last member submits, group auto-submits
4. Adviser sees both individual and group submissions

### Test 3: Approval Workflow
1. View draft submission in adviser dashboard
2. Click ✓ Approve
3. Verify status changes to "Approved"
4. Verify timestamp is recorded

## Troubleshooting

### Draft not appearing in adviser dashboard:
- Clear browser cache
- Refresh the page
- Check localStorage in browser DevTools

### Group not auto-submitting:
- Verify all group members are added to `group.members` array
- Check browser console for errors
- Ensure each member submitted their draft

### Missing notifications:
- Check if adviserNotifications is being saved
- Verify student role and group membership
- Check browser localStorage for data

## Future Features (In Development)

- Email notifications to adviser
- Draft comments and feedback
- Revision requests with feedback
- Draft version history
- Real-time notification counter in adviser header
- Scheduled draft reminders
- Draft comparison view
